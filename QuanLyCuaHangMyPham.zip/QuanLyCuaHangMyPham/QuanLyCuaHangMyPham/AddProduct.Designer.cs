﻿namespace QuanLyCuaHangMyPham
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.roundedPanel8 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.cbPartner = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.roundedPanel9 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.roundedPanel6 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.roundedPanel3 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.roundedPanel5 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.pnNewPartner = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.roundedPanel4 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtNameOfPartner = new System.Windows.Forms.TextBox();
            this.pnNewCategory = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.roundedPanel2 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtNameOfCategory = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.roundedPanel7 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txbTenSP = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.roundedPanel11 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtProductDescription = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.roundedPanel10 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtSource = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.roundedPanel12 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.txtUnit = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.roundedPanel15 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.nmGiaBan = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.roundedPanel13 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.nmGiaNhap = new System.Windows.Forms.NumericUpDown();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.roundedPanel14 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.nmAmount = new System.Windows.Forms.NumericUpDown();
            this.roundedPanel1 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.btnAddProduct = new QuanLyCuaHangMyPham.CustomDesign.ButtonCD();
            this.panel6.SuspendLayout();
            this.roundedPanel8.SuspendLayout();
            this.panel3.SuspendLayout();
            this.roundedPanel9.SuspendLayout();
            this.panel14.SuspendLayout();
            this.roundedPanel6.SuspendLayout();
            this.panel15.SuspendLayout();
            this.roundedPanel3.SuspendLayout();
            this.panel13.SuspendLayout();
            this.roundedPanel5.SuspendLayout();
            this.pnNewPartner.SuspendLayout();
            this.roundedPanel4.SuspendLayout();
            this.pnNewCategory.SuspendLayout();
            this.roundedPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.roundedPanel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.roundedPanel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.roundedPanel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.roundedPanel12.SuspendLayout();
            this.panel4.SuspendLayout();
            this.roundedPanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaBan)).BeginInit();
            this.panel2.SuspendLayout();
            this.roundedPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).BeginInit();
            this.panel5.SuspendLayout();
            this.roundedPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmAmount)).BeginInit();
            this.roundedPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.label11.Location = new System.Drawing.Point(15, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 18);
            this.label11.TabIndex = 6;
            this.label11.Text = "Thêm thủ công";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.roundedPanel8);
            this.panel6.Location = new System.Drawing.Point(429, 48);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(342, 59);
            this.panel6.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(15, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nhà cung cấp";
            this.label1.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel8
            // 
            this.roundedPanel8.BackColor = System.Drawing.Color.White;
            this.roundedPanel8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel8.BorderRadius = 6;
            this.roundedPanel8.BorderSize = 1;
            this.roundedPanel8.Controls.Add(this.cbPartner);
            this.roundedPanel8.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel8.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel8.Name = "roundedPanel8";
            this.roundedPanel8.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel8.TabIndex = 10;
            this.roundedPanel8.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // cbPartner
            // 
            this.cbPartner.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbPartner.FormattingEnabled = true;
            this.cbPartner.Items.AddRange(new object[] {
            "Thêm mới..."});
            this.cbPartner.Location = new System.Drawing.Point(11, 8);
            this.cbPartner.Name = "cbPartner";
            this.cbPartner.Size = new System.Drawing.Size(276, 26);
            this.cbPartner.TabIndex = 2;
            this.cbPartner.SelectedIndexChanged += new System.EventHandler(this.cbPartner_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.roundedPanel9);
            this.panel3.Location = new System.Drawing.Point(69, 48);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(342, 59);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(17, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 19);
            this.label14.TabIndex = 11;
            this.label14.Text = "Phân loại";
            this.label14.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel9
            // 
            this.roundedPanel9.BackColor = System.Drawing.Color.White;
            this.roundedPanel9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel9.BorderRadius = 6;
            this.roundedPanel9.BorderSize = 1;
            this.roundedPanel9.Controls.Add(this.cbCategory);
            this.roundedPanel9.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel9.Location = new System.Drawing.Point(2, 15);
            this.roundedPanel9.Name = "roundedPanel9";
            this.roundedPanel9.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel9.TabIndex = 10;
            this.roundedPanel9.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // cbCategory
            // 
            this.cbCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Thêm mới..."});
            this.cbCategory.Location = new System.Drawing.Point(11, 8);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(276, 26);
            this.cbCategory.TabIndex = 2;
            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label12);
            this.panel14.Controls.Add(this.roundedPanel6);
            this.panel14.Location = new System.Drawing.Point(429, 243);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(342, 59);
            this.panel14.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(15, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 19);
            this.label12.TabIndex = 11;
            this.label12.Text = "Số điện thoại";
            this.label12.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel6
            // 
            this.roundedPanel6.BackColor = System.Drawing.Color.White;
            this.roundedPanel6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel6.BorderRadius = 6;
            this.roundedPanel6.BorderSize = 1;
            this.roundedPanel6.Controls.Add(this.txtPhoneNumber);
            this.roundedPanel6.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel6.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel6.Name = "roundedPanel6";
            this.roundedPanel6.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel6.TabIndex = 10;
            this.roundedPanel6.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.BackColor = System.Drawing.Color.White;
            this.txtPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPhoneNumber.Location = new System.Drawing.Point(12, 12);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(12);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(266, 23);
            this.txtPhoneNumber.TabIndex = 1;
            this.txtPhoneNumber.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label3);
            this.panel15.Controls.Add(this.roundedPanel3);
            this.panel15.Location = new System.Drawing.Point(69, 178);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(342, 59);
            this.panel15.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(16, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 19);
            this.label3.TabIndex = 11;
            this.label3.Text = "Mô tả phân loại";
            this.label3.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel3
            // 
            this.roundedPanel3.BackColor = System.Drawing.Color.White;
            this.roundedPanel3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel3.BorderRadius = 6;
            this.roundedPanel3.BorderSize = 1;
            this.roundedPanel3.Controls.Add(this.txtCategory);
            this.roundedPanel3.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel3.Location = new System.Drawing.Point(1, 15);
            this.roundedPanel3.Name = "roundedPanel3";
            this.roundedPanel3.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel3.TabIndex = 10;
            this.roundedPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtCategory
            // 
            this.txtCategory.BackColor = System.Drawing.Color.White;
            this.txtCategory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCategory.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCategory.Location = new System.Drawing.Point(12, 12);
            this.txtCategory.Margin = new System.Windows.Forms.Padding(12);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(266, 23);
            this.txtCategory.TabIndex = 1;
            this.txtCategory.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.label10);
            this.panel13.Controls.Add(this.roundedPanel5);
            this.panel13.Location = new System.Drawing.Point(429, 178);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(342, 59);
            this.panel13.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(15, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 19);
            this.label10.TabIndex = 11;
            this.label10.Text = "Địa chỉ";
            this.label10.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel5
            // 
            this.roundedPanel5.BackColor = System.Drawing.Color.White;
            this.roundedPanel5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel5.BorderRadius = 6;
            this.roundedPanel5.BorderSize = 1;
            this.roundedPanel5.Controls.Add(this.txtAddress);
            this.roundedPanel5.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel5.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel5.Name = "roundedPanel5";
            this.roundedPanel5.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel5.TabIndex = 10;
            this.roundedPanel5.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.White;
            this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtAddress.Location = new System.Drawing.Point(12, 12);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(12);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(266, 23);
            this.txtAddress.TabIndex = 1;
            this.txtAddress.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // pnNewPartner
            // 
            this.pnNewPartner.Controls.Add(this.label8);
            this.pnNewPartner.Controls.Add(this.roundedPanel4);
            this.pnNewPartner.Location = new System.Drawing.Point(429, 113);
            this.pnNewPartner.Name = "pnNewPartner";
            this.pnNewPartner.Size = new System.Drawing.Size(342, 59);
            this.pnNewPartner.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(15, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 19);
            this.label8.TabIndex = 11;
            this.label8.Text = "Tên nhà cung cấp";
            this.label8.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel4
            // 
            this.roundedPanel4.BackColor = System.Drawing.Color.White;
            this.roundedPanel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel4.BorderRadius = 6;
            this.roundedPanel4.BorderSize = 1;
            this.roundedPanel4.Controls.Add(this.txtNameOfPartner);
            this.roundedPanel4.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel4.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel4.Name = "roundedPanel4";
            this.roundedPanel4.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel4.TabIndex = 10;
            this.roundedPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtNameOfPartner
            // 
            this.txtNameOfPartner.BackColor = System.Drawing.Color.White;
            this.txtNameOfPartner.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNameOfPartner.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameOfPartner.Location = new System.Drawing.Point(12, 12);
            this.txtNameOfPartner.Margin = new System.Windows.Forms.Padding(12);
            this.txtNameOfPartner.Name = "txtNameOfPartner";
            this.txtNameOfPartner.Size = new System.Drawing.Size(266, 23);
            this.txtNameOfPartner.TabIndex = 1;
            this.txtNameOfPartner.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // pnNewCategory
            // 
            this.pnNewCategory.Controls.Add(this.label9);
            this.pnNewCategory.Controls.Add(this.roundedPanel2);
            this.pnNewCategory.Location = new System.Drawing.Point(69, 113);
            this.pnNewCategory.Name = "pnNewCategory";
            this.pnNewCategory.Size = new System.Drawing.Size(342, 59);
            this.pnNewCategory.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(15, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 19);
            this.label9.TabIndex = 11;
            this.label9.Text = "Tên phân loại mới";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel2
            // 
            this.roundedPanel2.BackColor = System.Drawing.Color.White;
            this.roundedPanel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel2.BorderRadius = 6;
            this.roundedPanel2.BorderSize = 1;
            this.roundedPanel2.Controls.Add(this.txtNameOfCategory);
            this.roundedPanel2.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel2.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel2.Name = "roundedPanel2";
            this.roundedPanel2.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel2.TabIndex = 10;
            this.roundedPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtNameOfCategory
            // 
            this.txtNameOfCategory.BackColor = System.Drawing.Color.White;
            this.txtNameOfCategory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNameOfCategory.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNameOfCategory.Location = new System.Drawing.Point(12, 12);
            this.txtNameOfCategory.Margin = new System.Windows.Forms.Padding(12);
            this.txtNameOfCategory.Name = "txtNameOfCategory";
            this.txtNameOfCategory.Size = new System.Drawing.Size(266, 23);
            this.txtNameOfCategory.TabIndex = 1;
            this.txtNameOfCategory.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.roundedPanel7);
            this.panel1.Location = new System.Drawing.Point(69, 309);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 59);
            this.panel1.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label13.Location = new System.Drawing.Point(16, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 19);
            this.label13.TabIndex = 11;
            this.label13.Text = "Tên sản phẩm";
            this.label13.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel7
            // 
            this.roundedPanel7.BackColor = System.Drawing.Color.White;
            this.roundedPanel7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel7.BorderRadius = 6;
            this.roundedPanel7.BorderSize = 1;
            this.roundedPanel7.Controls.Add(this.txbTenSP);
            this.roundedPanel7.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel7.Location = new System.Drawing.Point(1, 15);
            this.roundedPanel7.Name = "roundedPanel7";
            this.roundedPanel7.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel7.TabIndex = 10;
            this.roundedPanel7.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txbTenSP
            // 
            this.txbTenSP.BackColor = System.Drawing.Color.White;
            this.txbTenSP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbTenSP.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txbTenSP.Location = new System.Drawing.Point(12, 12);
            this.txbTenSP.Margin = new System.Windows.Forms.Padding(12);
            this.txbTenSP.Name = "txbTenSP";
            this.txbTenSP.Size = new System.Drawing.Size(266, 23);
            this.txbTenSP.TabIndex = 1;
            this.txbTenSP.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.roundedPanel11);
            this.panel9.Location = new System.Drawing.Point(429, 504);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(342, 59);
            this.panel9.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(15, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 11;
            this.label6.Text = "Mô tả sản phẩm";
            this.label6.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel11
            // 
            this.roundedPanel11.BackColor = System.Drawing.Color.White;
            this.roundedPanel11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel11.BorderRadius = 6;
            this.roundedPanel11.BorderSize = 1;
            this.roundedPanel11.Controls.Add(this.txtProductDescription);
            this.roundedPanel11.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel11.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel11.Name = "roundedPanel11";
            this.roundedPanel11.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel11.TabIndex = 10;
            this.roundedPanel11.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtProductDescription
            // 
            this.txtProductDescription.BackColor = System.Drawing.Color.White;
            this.txtProductDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProductDescription.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtProductDescription.Location = new System.Drawing.Point(12, 12);
            this.txtProductDescription.Margin = new System.Windows.Forms.Padding(12);
            this.txtProductDescription.Name = "txtProductDescription";
            this.txtProductDescription.Size = new System.Drawing.Size(266, 23);
            this.txtProductDescription.TabIndex = 1;
            this.txtProductDescription.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.roundedPanel10);
            this.panel8.Location = new System.Drawing.Point(69, 504);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(342, 59);
            this.panel8.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(17, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 19);
            this.label15.TabIndex = 11;
            this.label15.Text = "Xuất xứ";
            this.label15.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel10
            // 
            this.roundedPanel10.BackColor = System.Drawing.Color.White;
            this.roundedPanel10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel10.BorderRadius = 6;
            this.roundedPanel10.BorderSize = 1;
            this.roundedPanel10.Controls.Add(this.txtSource);
            this.roundedPanel10.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel10.Location = new System.Drawing.Point(2, 15);
            this.roundedPanel10.Name = "roundedPanel10";
            this.roundedPanel10.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel10.TabIndex = 10;
            this.roundedPanel10.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtSource
            // 
            this.txtSource.BackColor = System.Drawing.Color.White;
            this.txtSource.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSource.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtSource.Location = new System.Drawing.Point(12, 12);
            this.txtSource.Margin = new System.Windows.Forms.Padding(12);
            this.txtSource.Name = "txtSource";
            this.txtSource.Size = new System.Drawing.Size(266, 23);
            this.txtSource.TabIndex = 1;
            this.txtSource.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.roundedPanel12);
            this.panel7.Location = new System.Drawing.Point(429, 439);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(342, 59);
            this.panel7.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(15, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Đơn vị tính";
            this.label7.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel12
            // 
            this.roundedPanel12.BackColor = System.Drawing.Color.White;
            this.roundedPanel12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel12.BorderRadius = 6;
            this.roundedPanel12.BorderSize = 1;
            this.roundedPanel12.Controls.Add(this.txtUnit);
            this.roundedPanel12.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel12.Location = new System.Drawing.Point(0, 11);
            this.roundedPanel12.Name = "roundedPanel12";
            this.roundedPanel12.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel12.TabIndex = 10;
            this.roundedPanel12.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // txtUnit
            // 
            this.txtUnit.BackColor = System.Drawing.Color.White;
            this.txtUnit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUnit.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtUnit.Location = new System.Drawing.Point(12, 12);
            this.txtUnit.Margin = new System.Windows.Forms.Padding(12);
            this.txtUnit.Name = "txtUnit";
            this.txtUnit.Size = new System.Drawing.Size(266, 23);
            this.txtUnit.TabIndex = 1;
            this.txtUnit.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.roundedPanel15);
            this.panel4.Location = new System.Drawing.Point(429, 374);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(342, 59);
            this.panel4.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(15, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Giá bán";
            this.label4.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel15
            // 
            this.roundedPanel15.BackColor = System.Drawing.Color.White;
            this.roundedPanel15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel15.BorderRadius = 6;
            this.roundedPanel15.BorderSize = 1;
            this.roundedPanel15.Controls.Add(this.nmGiaBan);
            this.roundedPanel15.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel15.Location = new System.Drawing.Point(0, 15);
            this.roundedPanel15.Name = "roundedPanel15";
            this.roundedPanel15.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel15.TabIndex = 10;
            this.roundedPanel15.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // nmGiaBan
            // 
            this.nmGiaBan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nmGiaBan.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nmGiaBan.Location = new System.Drawing.Point(15, 12);
            this.nmGiaBan.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.nmGiaBan.Name = "nmGiaBan";
            this.nmGiaBan.Size = new System.Drawing.Size(266, 20);
            this.nmGiaBan.TabIndex = 2;
            this.nmGiaBan.ThousandsSeparator = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.roundedPanel13);
            this.panel2.Location = new System.Drawing.Point(69, 374);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(342, 59);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Location = new System.Drawing.Point(16, 8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 19);
            this.label16.TabIndex = 11;
            this.label16.Text = "Giá nhập";
            this.label16.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel13
            // 
            this.roundedPanel13.BackColor = System.Drawing.Color.White;
            this.roundedPanel13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel13.BorderRadius = 6;
            this.roundedPanel13.BorderSize = 1;
            this.roundedPanel13.Controls.Add(this.nmGiaNhap);
            this.roundedPanel13.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel13.Location = new System.Drawing.Point(1, 15);
            this.roundedPanel13.Name = "roundedPanel13";
            this.roundedPanel13.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel13.TabIndex = 10;
            this.roundedPanel13.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // nmGiaNhap
            // 
            this.nmGiaNhap.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nmGiaNhap.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nmGiaNhap.Location = new System.Drawing.Point(16, 12);
            this.nmGiaNhap.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.nmGiaNhap.Name = "nmGiaNhap";
            this.nmGiaNhap.Size = new System.Drawing.Size(265, 20);
            this.nmGiaNhap.TabIndex = 2;
            this.nmGiaNhap.ThousandsSeparator = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.roundedPanel14);
            this.panel5.Location = new System.Drawing.Point(69, 439);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(342, 59);
            this.panel5.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(16, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 19);
            this.label2.TabIndex = 11;
            this.label2.Text = "Số lượng";
            this.label2.Click += new System.EventHandler(this.label9_Click);
            // 
            // roundedPanel14
            // 
            this.roundedPanel14.BackColor = System.Drawing.Color.White;
            this.roundedPanel14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.roundedPanel14.BorderRadius = 6;
            this.roundedPanel14.BorderSize = 1;
            this.roundedPanel14.Controls.Add(this.nmAmount);
            this.roundedPanel14.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel14.Location = new System.Drawing.Point(1, 15);
            this.roundedPanel14.Name = "roundedPanel14";
            this.roundedPanel14.Size = new System.Drawing.Size(290, 37);
            this.roundedPanel14.TabIndex = 10;
            this.roundedPanel14.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel2_Paint);
            // 
            // nmAmount
            // 
            this.nmAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nmAmount.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nmAmount.Location = new System.Drawing.Point(14, 12);
            this.nmAmount.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.nmAmount.Name = "nmAmount";
            this.nmAmount.Size = new System.Drawing.Size(267, 20);
            this.nmAmount.TabIndex = 2;
            this.nmAmount.ThousandsSeparator = true;
            // 
            // roundedPanel1
            // 
            this.roundedPanel1.BackColor = System.Drawing.Color.White;
            this.roundedPanel1.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel1.BorderRadius = 20;
            this.roundedPanel1.BorderSize = 0;
            this.roundedPanel1.Controls.Add(this.btnAddProduct);
            this.roundedPanel1.Controls.Add(this.label11);
            this.roundedPanel1.Controls.Add(this.panel5);
            this.roundedPanel1.Controls.Add(this.panel6);
            this.roundedPanel1.Controls.Add(this.panel2);
            this.roundedPanel1.Controls.Add(this.panel3);
            this.roundedPanel1.Controls.Add(this.panel4);
            this.roundedPanel1.Controls.Add(this.panel7);
            this.roundedPanel1.Controls.Add(this.panel14);
            this.roundedPanel1.Controls.Add(this.panel8);
            this.roundedPanel1.Controls.Add(this.panel15);
            this.roundedPanel1.Controls.Add(this.panel9);
            this.roundedPanel1.Controls.Add(this.panel13);
            this.roundedPanel1.Controls.Add(this.panel1);
            this.roundedPanel1.Controls.Add(this.pnNewPartner);
            this.roundedPanel1.Controls.Add(this.pnNewCategory);
            this.roundedPanel1.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel1.Location = new System.Drawing.Point(15, 15);
            this.roundedPanel1.Margin = new System.Windows.Forms.Padding(15);
            this.roundedPanel1.Name = "roundedPanel1";
            this.roundedPanel1.Size = new System.Drawing.Size(775, 671);
            this.roundedPanel1.TabIndex = 7;
            this.roundedPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.roundedPanel1_Paint);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
            this.btnAddProduct.BorderColor = System.Drawing.Color.AliceBlue;
            this.btnAddProduct.BorderRadius = 20;
            this.btnAddProduct.BorderSize = 0;
            this.btnAddProduct.FlatAppearance.BorderSize = 0;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAddProduct.ForeColor = System.Drawing.Color.White;
            this.btnAddProduct.Location = new System.Drawing.Point(280, 586);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(220, 50);
            this.btnAddProduct.TabIndex = 7;
            this.btnAddProduct.Text = "THÊM";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.button1_Click);
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(803, 699);
            this.Controls.Add(this.roundedPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "AddProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddProduct";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddProduct_FormClosing);
            this.Load += new System.EventHandler(this.AddProduct_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.roundedPanel8.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.roundedPanel9.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.roundedPanel6.ResumeLayout(false);
            this.roundedPanel6.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.roundedPanel3.ResumeLayout(false);
            this.roundedPanel3.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.roundedPanel5.ResumeLayout(false);
            this.roundedPanel5.PerformLayout();
            this.pnNewPartner.ResumeLayout(false);
            this.pnNewPartner.PerformLayout();
            this.roundedPanel4.ResumeLayout(false);
            this.roundedPanel4.PerformLayout();
            this.pnNewCategory.ResumeLayout(false);
            this.pnNewCategory.PerformLayout();
            this.roundedPanel2.ResumeLayout(false);
            this.roundedPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.roundedPanel7.ResumeLayout(false);
            this.roundedPanel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.roundedPanel11.ResumeLayout(false);
            this.roundedPanel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.roundedPanel10.ResumeLayout(false);
            this.roundedPanel10.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.roundedPanel12.ResumeLayout(false);
            this.roundedPanel12.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.roundedPanel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaBan)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.roundedPanel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.roundedPanel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmAmount)).EndInit();
            this.roundedPanel1.ResumeLayout(false);
            this.roundedPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Label label11;
        private Panel panel6;
        private ComboBox cbPartner;
        private Panel panel3;
        private Panel panel14;
        private Panel panel15;
        private Panel panel13;
        private Panel pnNewPartner;
        private Panel pnNewCategory;
        private Panel panel1;
        private Panel panel7;
        private Panel panel4;
        private Panel panel2;
        private Panel panel5;
        private Panel panel8;
        private Panel panel9;
        public NumericUpDown nmGiaNhap;
        private CustomDesign.RoundedPanel roundedPanel1;
        private Label label9;
        private CustomDesign.RoundedPanel roundedPanel2;
        private TextBox txtNameOfCategory;
        private Label label3;
        private CustomDesign.RoundedPanel roundedPanel3;
        private TextBox txtCategory;
        private Label label8;
        private CustomDesign.RoundedPanel roundedPanel4;
        private TextBox txtNameOfPartner;
        private Label label10;
        private CustomDesign.RoundedPanel roundedPanel5;
        private TextBox txtAddress;
        private Label label12;
        private CustomDesign.RoundedPanel roundedPanel6;
        private TextBox txtPhoneNumber;
        private Label label13;
        private CustomDesign.RoundedPanel roundedPanel7;
        private TextBox txbTenSP;
        private Label label1;
        private CustomDesign.RoundedPanel roundedPanel8;
        private Label label14;
        private CustomDesign.RoundedPanel roundedPanel9;
        private ComboBox cbCategory;
        private Label label15;
        private CustomDesign.RoundedPanel roundedPanel10;
        private TextBox txtSource;
        private Label label6;
        private CustomDesign.RoundedPanel roundedPanel11;
        private TextBox txtProductDescription;
        private Label label7;
        private CustomDesign.RoundedPanel roundedPanel12;
        private TextBox txtUnit;
        private Label label16;
        private CustomDesign.RoundedPanel roundedPanel13;
        private Label label4;
        private CustomDesign.RoundedPanel roundedPanel15;
        public NumericUpDown nmGiaBan;
        private Label label2;
        private CustomDesign.RoundedPanel roundedPanel14;
        public NumericUpDown nmAmount;
        private CustomDesign.ButtonCD btnAddProduct;
    }
}