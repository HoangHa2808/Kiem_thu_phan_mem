﻿//namespace QuanLyCuaHangMyPham
//{
//    partial class fTransaction
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fTransaction));
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
//            this.panel2 = new System.Windows.Forms.Panel();
//            this.panel3 = new System.Windows.Forms.Panel();
//            this.showTimeDB = new System.Windows.Forms.Label();
//            this.pictureBox2 = new System.Windows.Forms.PictureBox();
//            this.panel4 = new System.Windows.Forms.Panel();
//            this.pictureBox1 = new System.Windows.Forms.PictureBox();
//            this.textBox1 = new System.Windows.Forms.TextBox();
//            this.panel1 = new System.Windows.Forms.Panel();
//            this.tableListProduct = new System.Windows.Forms.TableLayoutPanel();
//            this.label3 = new System.Windows.Forms.Label();
//            this.label4 = new System.Windows.Forms.Label();
//            this.label9 = new System.Windows.Forms.Label();
//            this.nav_sell = new System.Windows.Forms.Button();
//            this.nav_product = new System.Windows.Forms.Button();
//            this.navForAdmin = new System.Windows.Forms.Panel();
//            this.nav_purchase = new System.Windows.Forms.Button();
//            this.nav_bill = new System.Windows.Forms.Button();
//            this.nav_report = new System.Windows.Forms.Button();
//            this.panelMenu = new System.Windows.Forms.Panel();
//            this.roundedPanel1 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.dtgvListProduct = new System.Windows.Forms.DataGridView();
//            this.roundedPanel3 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.buttoncd1 = new QuanLyCuaHangMyPham.CustomDesign.ButtonCD();
//            this.label13 = new System.Windows.Forms.Label();
//            this.roundedPanel5 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.label11 = new System.Windows.Forms.Label();
//            this.label14 = new System.Windows.Forms.Label();
//            this.roundedPanel7 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.textBox4 = new System.Windows.Forms.TextBox();
//            this.label23 = new System.Windows.Forms.Label();
//            this.roundedPanel10 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.textBox6 = new System.Windows.Forms.TextBox();
//            this.label16 = new System.Windows.Forms.Label();
//            this.roundedPanel8 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.textBox5 = new System.Windows.Forms.TextBox();
//            this.label15 = new System.Windows.Forms.Label();
//            this.roundedPanel2 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.textBox2 = new System.Windows.Forms.TextBox();
//            this.label2 = new System.Windows.Forms.Label();
//            this.roundedPanel4 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.label12 = new System.Windows.Forms.Label();
//            this.roundedPanel6 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.textBox3 = new System.Windows.Forms.TextBox();
//            this.label1 = new System.Windows.Forms.Label();
//            this.roundedPanel9 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
//            this.buttoncd2 = new QuanLyCuaHangMyPham.CustomDesign.ButtonCD();
//            this.label22 = new System.Windows.Forms.Label();
//            this.label20 = new System.Windows.Forms.Label();
//            this.label18 = new System.Windows.Forms.Label();
//            this.label10 = new System.Windows.Forms.Label();
//            this.label7 = new System.Windows.Forms.Label();
//            this.label21 = new System.Windows.Forms.Label();
//            this.label19 = new System.Windows.Forms.Label();
//            this.label17 = new System.Windows.Forms.Label();
//            this.label8 = new System.Windows.Forms.Label();
//            this.label6 = new System.Windows.Forms.Label();
//            this.dataGridView1 = new System.Windows.Forms.DataGridView();
//            this.label5 = new System.Windows.Forms.Label();
//            this.panel9 = new System.Windows.Forms.Panel();
//            this.txtDisplayName = new System.Windows.Forms.TextBox();
//            this.pictureBox7 = new System.Windows.Forms.PictureBox();
//            this.displayName = new System.Windows.Forms.Label();
//            this.panel2.SuspendLayout();
//            this.panel3.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
//            this.panel4.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
//            this.tableListProduct.SuspendLayout();
//            this.navForAdmin.SuspendLayout();
//            this.panelMenu.SuspendLayout();
//            this.roundedPanel1.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.dtgvListProduct)).BeginInit();
//            this.roundedPanel3.SuspendLayout();
//            this.roundedPanel5.SuspendLayout();
//            this.roundedPanel7.SuspendLayout();
//            this.roundedPanel10.SuspendLayout();
//            this.roundedPanel8.SuspendLayout();
//            this.roundedPanel2.SuspendLayout();
//            this.roundedPanel4.SuspendLayout();
//            this.roundedPanel6.SuspendLayout();
//            this.roundedPanel9.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
//            this.panel9.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
//            this.SuspendLayout();
//            // 
//            // panel2
//            // 
//            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.panel2.BackColor = System.Drawing.Color.White;
//            this.panel2.Controls.Add(this.panel9);
//            this.panel2.Controls.Add(this.panel3);
//            this.panel2.Controls.Add(this.panel4);
//            this.panel2.Location = new System.Drawing.Point(229, 0);
//            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.panel2.Name = "panel2";
//            this.panel2.Size = new System.Drawing.Size(1627, 91);
//            this.panel2.TabIndex = 5;
//            // 
//            // panel3
//            // 
//            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
//            this.panel3.BackColor = System.Drawing.Color.White;
//            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
//            this.panel3.Controls.Add(this.showTimeDB);
//            this.panel3.Controls.Add(this.pictureBox2);
//            this.panel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(143)))), ((int)(((byte)(172)))));
//            this.panel3.Location = new System.Drawing.Point(1856, -21);
//            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.panel3.Name = "panel3";
//            this.panel3.Size = new System.Drawing.Size(163, 53);
//            this.panel3.TabIndex = 3;
//            // 
//            // showTimeDB
//            // 
//            this.showTimeDB.AutoSize = true;
//            this.showTimeDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.showTimeDB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
//            this.showTimeDB.Location = new System.Drawing.Point(62, 17);
//            this.showTimeDB.MaximumSize = new System.Drawing.Size(79, 19);
//            this.showTimeDB.MinimumSize = new System.Drawing.Size(79, 19);
//            this.showTimeDB.Name = "showTimeDB";
//            this.showTimeDB.Size = new System.Drawing.Size(79, 19);
//            this.showTimeDB.TabIndex = 3;
//            this.showTimeDB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // pictureBox2
//            // 
//            this.pictureBox2.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_calendar;
//            this.pictureBox2.Location = new System.Drawing.Point(23, 11);
//            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.pictureBox2.Name = "pictureBox2";
//            this.pictureBox2.Size = new System.Drawing.Size(27, 32);
//            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
//            this.pictureBox2.TabIndex = 2;
//            this.pictureBox2.TabStop = false;
//            // 
//            // panel4
//            // 
//            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            this.panel4.Controls.Add(this.pictureBox1);
//            this.panel4.Controls.Add(this.textBox1);
//            this.panel4.Location = new System.Drawing.Point(43, 21);
//            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.panel4.Name = "panel4";
//            this.panel4.Size = new System.Drawing.Size(229, 55);
//            this.panel4.TabIndex = 0;
//            // 
//            // pictureBox1
//            // 
//            this.pictureBox1.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_search;
//            this.pictureBox1.Location = new System.Drawing.Point(11, 16);
//            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.pictureBox1.Name = "pictureBox1";
//            this.pictureBox1.Size = new System.Drawing.Size(18, 21);
//            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
//            this.pictureBox1.TabIndex = 1;
//            this.pictureBox1.TabStop = false;
//            // 
//            // textBox1
//            // 
//            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            this.textBox1.Location = new System.Drawing.Point(37, 12);
//            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox1.Name = "textBox1";
//            this.textBox1.PlaceholderText = "Tìm sản phẩm";
//            this.textBox1.Size = new System.Drawing.Size(188, 27);
//            this.textBox1.TabIndex = 5;
//            // 
//            // panel1
//            // 
//            this.panel1.BackColor = System.Drawing.Color.White;
//            this.panel1.Location = new System.Drawing.Point(0, 0);
//            this.panel1.Name = "panel1";
//            this.panel1.Size = new System.Drawing.Size(200, 100);
//            this.panel1.TabIndex = 0;
//            // 
//            // tableListProduct
//            // 
//            this.tableListProduct.Anchor = System.Windows.Forms.AnchorStyles.Left;
//            this.tableListProduct.AutoScroll = true;
//            this.tableListProduct.ColumnCount = 6;
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
//            this.tableListProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
//            this.tableListProduct.Controls.Add(this.label3, 1, 0);
//            this.tableListProduct.Location = new System.Drawing.Point(0, 0);
//            this.tableListProduct.Name = "tableListProduct";
//            this.tableListProduct.RowCount = 1;
//            this.tableListProduct.Size = new System.Drawing.Size(200, 100);
//            this.tableListProduct.TabIndex = 0;
//            // 
//            // label3
//            // 
//            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
//            this.label3.AutoSize = true;
//            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
//            this.label3.Location = new System.Drawing.Point(13, 0);
//            this.label3.Name = "label3";
//            this.label3.Size = new System.Drawing.Size(14, 180);
//            this.label3.TabIndex = 0;
//            this.label3.Text = "Mã sản phâm";
//            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // label4
//            // 
//            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
//            this.label4.AutoSize = true;
//            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
//            this.label4.Location = new System.Drawing.Point(154, 290);
//            this.label4.Name = "label4";
//            this.label4.Size = new System.Drawing.Size(80, 15);
//            this.label4.TabIndex = 0;
//            this.label4.Text = "Tên sản phâm";
//            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // label9
//            // 
//            this.label9.AutoSize = true;
//            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
//            this.label9.Location = new System.Drawing.Point(17, 20);
//            this.label9.Name = "label9";
//            this.label9.Size = new System.Drawing.Size(110, 25);
//            this.label9.TabIndex = 0;
//            this.label9.Text = "Sản phẩm";
//            // 
//            // nav_sell
//            // 
//            this.nav_sell.BackColor = System.Drawing.Color.White;
//            this.nav_sell.FlatAppearance.BorderColor = System.Drawing.Color.White;
//            this.nav_sell.FlatAppearance.BorderSize = 0;
//            this.nav_sell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.nav_sell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
//            this.nav_sell.Image = ((System.Drawing.Image)(resources.GetObject("nav_sell.Image")));
//            this.nav_sell.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_sell.Location = new System.Drawing.Point(23, 347);
//            this.nav_sell.Margin = new System.Windows.Forms.Padding(0);
//            this.nav_sell.Name = "nav_sell";
//            this.nav_sell.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
//            this.nav_sell.Size = new System.Drawing.Size(183, 53);
//            this.nav_sell.TabIndex = 4;
//            this.nav_sell.Text = "        Bán hàng";
//            this.nav_sell.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_sell.UseVisualStyleBackColor = false;
//            this.nav_sell.Click += new System.EventHandler(this.nav_sell_Click);
//            // 
//            // nav_product
//            // 
//            this.nav_product.BackColor = System.Drawing.Color.White;
//            this.nav_product.FlatAppearance.BorderColor = System.Drawing.Color.White;
//            this.nav_product.FlatAppearance.BorderSize = 0;
//            this.nav_product.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.nav_product.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
//            this.nav_product.Image = ((System.Drawing.Image)(resources.GetObject("nav_product.Image")));
//            this.nav_product.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_product.Location = new System.Drawing.Point(23, 407);
//            this.nav_product.Margin = new System.Windows.Forms.Padding(0);
//            this.nav_product.Name = "nav_product";
//            this.nav_product.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
//            this.nav_product.Size = new System.Drawing.Size(183, 53);
//            this.nav_product.TabIndex = 4;
//            this.nav_product.Text = "        Sản phẩm";
//            this.nav_product.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_product.UseVisualStyleBackColor = false;
//            this.nav_product.Click += new System.EventHandler(this.nav_product_Click);
//            // 
//            // navForAdmin
//            // 
//            this.navForAdmin.Controls.Add(this.nav_purchase);
//            this.navForAdmin.Controls.Add(this.nav_bill);
//            this.navForAdmin.Controls.Add(this.nav_report);
//            this.navForAdmin.Location = new System.Drawing.Point(0, 467);
//            this.navForAdmin.Margin = new System.Windows.Forms.Padding(0);
//            this.navForAdmin.Name = "navForAdmin";
//            this.navForAdmin.Size = new System.Drawing.Size(229, 187);
//            this.navForAdmin.TabIndex = 5;
//            // 
//            // nav_purchase
//            // 
//            this.nav_purchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
//            this.nav_purchase.FlatAppearance.BorderColor = System.Drawing.Color.White;
//            this.nav_purchase.FlatAppearance.BorderSize = 0;
//            this.nav_purchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.nav_purchase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            this.nav_purchase.Image = ((System.Drawing.Image)(resources.GetObject("nav_purchase.Image")));
//            this.nav_purchase.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_purchase.Location = new System.Drawing.Point(23, 0);
//            this.nav_purchase.Margin = new System.Windows.Forms.Padding(0);
//            this.nav_purchase.Name = "nav_purchase";
//            this.nav_purchase.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
//            this.nav_purchase.Size = new System.Drawing.Size(183, 53);
//            this.nav_purchase.TabIndex = 4;
//            this.nav_purchase.Text = "        Nhập hàng";
//            this.nav_purchase.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_purchase.UseVisualStyleBackColor = false;
//            // 
//            // nav_bill
//            // 
//            this.nav_bill.BackColor = System.Drawing.Color.White;
//            this.nav_bill.FlatAppearance.BorderColor = System.Drawing.Color.White;
//            this.nav_bill.FlatAppearance.BorderSize = 0;
//            this.nav_bill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.nav_bill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
//            this.nav_bill.Image = ((System.Drawing.Image)(resources.GetObject("nav_bill.Image")));
//            this.nav_bill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_bill.Location = new System.Drawing.Point(23, 60);
//            this.nav_bill.Margin = new System.Windows.Forms.Padding(0);
//            this.nav_bill.Name = "nav_bill";
//            this.nav_bill.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
//            this.nav_bill.Size = new System.Drawing.Size(183, 53);
//            this.nav_bill.TabIndex = 4;
//            this.nav_bill.Text = "        Hóa đơn";
//            this.nav_bill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_bill.UseVisualStyleBackColor = false;
//            this.nav_bill.Click += new System.EventHandler(this.nav_bill_Click);
//            // 
//            // nav_report
//            // 
//            this.nav_report.BackColor = System.Drawing.Color.White;
//            this.nav_report.FlatAppearance.BorderColor = System.Drawing.Color.White;
//            this.nav_report.FlatAppearance.BorderSize = 0;
//            this.nav_report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.nav_report.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
//            this.nav_report.Image = ((System.Drawing.Image)(resources.GetObject("nav_report.Image")));
//            this.nav_report.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_report.Location = new System.Drawing.Point(23, 120);
//            this.nav_report.Margin = new System.Windows.Forms.Padding(0);
//            this.nav_report.Name = "nav_report";
//            this.nav_report.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
//            this.nav_report.Size = new System.Drawing.Size(183, 53);
//            this.nav_report.TabIndex = 4;
//            this.nav_report.Text = "        Báo cáo";
//            this.nav_report.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            this.nav_report.UseVisualStyleBackColor = false;
//            this.nav_report.Click += new System.EventHandler(this.nav_report_Click);
//            // 
//            // panelMenu
//            // 
//            this.panelMenu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Left)));
//            this.panelMenu.BackColor = System.Drawing.Color.White;
//            this.panelMenu.Controls.Add(this.navForAdmin);
//            this.panelMenu.Controls.Add(this.nav_product);
//            this.panelMenu.Controls.Add(this.nav_sell);
//            this.panelMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.panelMenu.Location = new System.Drawing.Point(0, 0);
//            this.panelMenu.Margin = new System.Windows.Forms.Padding(0);
//            this.panelMenu.Name = "panelMenu";
//            this.panelMenu.Size = new System.Drawing.Size(229, 1015);
//            this.panelMenu.TabIndex = 2;
//            this.panelMenu.Tag = "P";
//            // 
//            // roundedPanel1
//            // 
//            this.roundedPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Left) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.roundedPanel1.BackColor = System.Drawing.Color.White;
//            this.roundedPanel1.BorderColor = System.Drawing.SystemColors.ButtonFace;
//            this.roundedPanel1.BorderRadius = 20;
//            this.roundedPanel1.BorderSize = 2;
//            this.roundedPanel1.Controls.Add(this.dtgvListProduct);
//            this.roundedPanel1.Controls.Add(this.label9);
//            this.roundedPanel1.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel1.Location = new System.Drawing.Point(242, 107);
//            this.roundedPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel1.Name = "roundedPanel1";
//            this.roundedPanel1.Size = new System.Drawing.Size(656, 892);
//            this.roundedPanel1.TabIndex = 7;
//            // 
//            // dtgvListProduct
//            // 
//            this.dtgvListProduct.AllowUserToAddRows = false;
//            this.dtgvListProduct.AllowUserToDeleteRows = false;
//            this.dtgvListProduct.AllowUserToOrderColumns = true;
//            this.dtgvListProduct.AllowUserToResizeRows = false;
//            this.dtgvListProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
//            this.dtgvListProduct.BackgroundColor = System.Drawing.Color.White;
//            this.dtgvListProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.dtgvListProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
//            this.dtgvListProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
//            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
//            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
//            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
//            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
//            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
//            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
//            this.dtgvListProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
//            this.dtgvListProduct.ColumnHeadersHeight = 50;
//            this.dtgvListProduct.GridColor = System.Drawing.Color.White;
//            this.dtgvListProduct.Location = new System.Drawing.Point(17, 89);
//            this.dtgvListProduct.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.dtgvListProduct.Name = "dtgvListProduct";
//            this.dtgvListProduct.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
//            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
//            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
//            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
//            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
//            this.dtgvListProduct.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
//            this.dtgvListProduct.RowHeadersVisible = false;
//            this.dtgvListProduct.RowHeadersWidth = 50;
//            this.dtgvListProduct.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
//            this.dtgvListProduct.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            this.dtgvListProduct.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            this.dtgvListProduct.RowTemplate.Height = 40;
//            this.dtgvListProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
//            this.dtgvListProduct.Size = new System.Drawing.Size(606, 751);
//            this.dtgvListProduct.TabIndex = 7;
//            // 
//            // roundedPanel3
//            // 
//            this.roundedPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Left) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.roundedPanel3.BackColor = System.Drawing.Color.White;
//            this.roundedPanel3.BorderColor = System.Drawing.SystemColors.ButtonFace;
//            this.roundedPanel3.BorderRadius = 20;
//            this.roundedPanel3.BorderSize = 2;
//            this.roundedPanel3.Controls.Add(this.buttoncd1);
//            this.roundedPanel3.Controls.Add(this.label13);
//            this.roundedPanel3.Controls.Add(this.roundedPanel5);
//            this.roundedPanel3.Controls.Add(this.label14);
//            this.roundedPanel3.Controls.Add(this.roundedPanel7);
//            this.roundedPanel3.Controls.Add(this.label23);
//            this.roundedPanel3.Controls.Add(this.roundedPanel10);
//            this.roundedPanel3.Controls.Add(this.label16);
//            this.roundedPanel3.Controls.Add(this.roundedPanel8);
//            this.roundedPanel3.Controls.Add(this.label15);
//            this.roundedPanel3.Controls.Add(this.roundedPanel2);
//            this.roundedPanel3.Controls.Add(this.label2);
//            this.roundedPanel3.Controls.Add(this.roundedPanel4);
//            this.roundedPanel3.Controls.Add(this.roundedPanel6);
//            this.roundedPanel3.Controls.Add(this.label1);
//            this.roundedPanel3.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel3.Location = new System.Drawing.Point(917, 108);
//            this.roundedPanel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel3.Name = "roundedPanel3";
//            this.roundedPanel3.Size = new System.Drawing.Size(381, 892);
//            this.roundedPanel3.TabIndex = 8;
//            // 
//            // buttoncd1
//            // 
//            this.buttoncd1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            this.buttoncd1.BorderColor = System.Drawing.Color.AliceBlue;
//            this.buttoncd1.BorderRadius = 20;
//            this.buttoncd1.BorderSize = 0;
//            this.buttoncd1.FlatAppearance.BorderSize = 0;
//            this.buttoncd1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.buttoncd1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.buttoncd1.ForeColor = System.Drawing.Color.White;
//            this.buttoncd1.Location = new System.Drawing.Point(71, 785);
//            this.buttoncd1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.buttoncd1.Name = "buttoncd1";
//            this.buttoncd1.Size = new System.Drawing.Size(206, 67);
//            this.buttoncd1.TabIndex = 5;
//            this.buttoncd1.Text = "Nhập hàng";
//            this.buttoncd1.UseVisualStyleBackColor = false;
//            // 
//            // label13
//            // 
//            this.label13.AutoSize = true;
//            this.label13.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label13.Location = new System.Drawing.Point(111, 197);
//            this.label13.Name = "label13";
//            this.label13.Size = new System.Drawing.Size(94, 19);
//            this.label13.TabIndex = 4;
//            this.label13.Text = "Tên sản phẩm";
//            // 
//            // roundedPanel5
//            // 
//            this.roundedPanel5.BackColor = System.Drawing.Color.White;
//            this.roundedPanel5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel5.BorderRadius = 6;
//            this.roundedPanel5.BorderSize = 1;
//            this.roundedPanel5.Controls.Add(this.label11);
//            this.roundedPanel5.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel5.Location = new System.Drawing.Point(94, 207);
//            this.roundedPanel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel5.Name = "roundedPanel5";
//            this.roundedPanel5.Size = new System.Drawing.Size(183, 53);
//            this.roundedPanel5.TabIndex = 3;
//            // 
//            // label11
//            // 
//            this.label11.AutoSize = true;
//            this.label11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label11.Location = new System.Drawing.Point(14, 16);
//            this.label11.Name = "label11";
//            this.label11.Size = new System.Drawing.Size(116, 23);
//            this.label11.TabIndex = 4;
//            this.label11.Text = "Tên sản phẩm";
//            // 
//            // label14
//            // 
//            this.label14.AutoSize = true;
//            this.label14.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label14.Location = new System.Drawing.Point(107, 392);
//            this.label14.Name = "label14";
//            this.label14.Size = new System.Drawing.Size(63, 19);
//            this.label14.TabIndex = 4;
//            this.label14.Text = "Số lượng";
//            // 
//            // roundedPanel7
//            // 
//            this.roundedPanel7.BackColor = System.Drawing.Color.White;
//            this.roundedPanel7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel7.BorderRadius = 6;
//            this.roundedPanel7.BorderSize = 1;
//            this.roundedPanel7.Controls.Add(this.textBox4);
//            this.roundedPanel7.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel7.Location = new System.Drawing.Point(90, 401);
//            this.roundedPanel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel7.Name = "roundedPanel7";
//            this.roundedPanel7.Size = new System.Drawing.Size(183, 49);
//            this.roundedPanel7.TabIndex = 3;
//            // 
//            // textBox4
//            // 
//            this.textBox4.BackColor = System.Drawing.Color.White;
//            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.textBox4.Location = new System.Drawing.Point(14, 16);
//            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox4.Name = "textBox4";
//            this.textBox4.Size = new System.Drawing.Size(143, 23);
//            this.textBox4.TabIndex = 1;
//            // 
//            // label23
//            // 
//            this.label23.AutoSize = true;
//            this.label23.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label23.Location = new System.Drawing.Point(104, 593);
//            this.label23.Name = "label23";
//            this.label23.Size = new System.Drawing.Size(52, 19);
//            this.label23.TabIndex = 4;
//            this.label23.Text = "Đối tác";
//            // 
//            // roundedPanel10
//            // 
//            this.roundedPanel10.BackColor = System.Drawing.Color.White;
//            this.roundedPanel10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel10.BorderRadius = 6;
//            this.roundedPanel10.BorderSize = 1;
//            this.roundedPanel10.Controls.Add(this.textBox6);
//            this.roundedPanel10.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel10.Location = new System.Drawing.Point(87, 601);
//            this.roundedPanel10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel10.Name = "roundedPanel10";
//            this.roundedPanel10.Size = new System.Drawing.Size(183, 49);
//            this.roundedPanel10.TabIndex = 3;
//            // 
//            // textBox6
//            // 
//            this.textBox6.BackColor = System.Drawing.Color.White;
//            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.textBox6.Location = new System.Drawing.Point(14, 16);
//            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox6.Name = "textBox6";
//            this.textBox6.Size = new System.Drawing.Size(143, 23);
//            this.textBox6.TabIndex = 1;
//            // 
//            // label16
//            // 
//            this.label16.AutoSize = true;
//            this.label16.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label16.Location = new System.Drawing.Point(107, 496);
//            this.label16.Name = "label16";
//            this.label16.Size = new System.Drawing.Size(63, 19);
//            this.label16.TabIndex = 4;
//            this.label16.Text = "Giảm giá";
//            // 
//            // roundedPanel8
//            // 
//            this.roundedPanel8.BackColor = System.Drawing.Color.White;
//            this.roundedPanel8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel8.BorderRadius = 6;
//            this.roundedPanel8.BorderSize = 1;
//            this.roundedPanel8.Controls.Add(this.textBox5);
//            this.roundedPanel8.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel8.Location = new System.Drawing.Point(90, 504);
//            this.roundedPanel8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel8.Name = "roundedPanel8";
//            this.roundedPanel8.Size = new System.Drawing.Size(183, 49);
//            this.roundedPanel8.TabIndex = 3;
//            // 
//            // textBox5
//            // 
//            this.textBox5.BackColor = System.Drawing.Color.White;
//            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.textBox5.Location = new System.Drawing.Point(14, 16);
//            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox5.Name = "textBox5";
//            this.textBox5.Size = new System.Drawing.Size(143, 23);
//            this.textBox5.TabIndex = 1;
//            // 
//            // label15
//            // 
//            this.label15.AutoSize = true;
//            this.label15.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label15.Location = new System.Drawing.Point(111, 296);
//            this.label15.Name = "label15";
//            this.label15.Size = new System.Drawing.Size(57, 19);
//            this.label15.TabIndex = 4;
//            this.label15.Text = "Đơn giá";
//            // 
//            // roundedPanel2
//            // 
//            this.roundedPanel2.BackColor = System.Drawing.Color.White;
//            this.roundedPanel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel2.BorderRadius = 6;
//            this.roundedPanel2.BorderSize = 1;
//            this.roundedPanel2.Controls.Add(this.textBox2);
//            this.roundedPanel2.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel2.Location = new System.Drawing.Point(94, 305);
//            this.roundedPanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel2.Name = "roundedPanel2";
//            this.roundedPanel2.Size = new System.Drawing.Size(183, 49);
//            this.roundedPanel2.TabIndex = 3;
//            // 
//            // textBox2
//            // 
//            this.textBox2.BackColor = System.Drawing.Color.White;
//            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.textBox2.Location = new System.Drawing.Point(14, 16);
//            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox2.Name = "textBox2";
//            this.textBox2.Size = new System.Drawing.Size(143, 23);
//            this.textBox2.TabIndex = 1;
//            // 
//            // label2
//            // 
//            this.label2.AutoSize = true;
//            this.label2.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label2.Location = new System.Drawing.Point(111, 95);
//            this.label2.Name = "label2";
//            this.label2.Size = new System.Drawing.Size(93, 19);
//            this.label2.TabIndex = 4;
//            this.label2.Text = "Mã sản phẩm";
//            // 
//            // roundedPanel4
//            // 
//            this.roundedPanel4.BackColor = System.Drawing.Color.White;
//            this.roundedPanel4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel4.BorderRadius = 6;
//            this.roundedPanel4.BorderSize = 1;
//            this.roundedPanel4.Controls.Add(this.label12);
//            this.roundedPanel4.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel4.Location = new System.Drawing.Point(94, 104);
//            this.roundedPanel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel4.Name = "roundedPanel4";
//            this.roundedPanel4.Size = new System.Drawing.Size(183, 53);
//            this.roundedPanel4.TabIndex = 3;
//            // 
//            // label12
//            // 
//            this.label12.AutoSize = true;
//            this.label12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label12.Location = new System.Drawing.Point(14, 16);
//            this.label12.Name = "label12";
//            this.label12.Size = new System.Drawing.Size(114, 23);
//            this.label12.TabIndex = 4;
//            this.label12.Text = "Mã sản phẩm";
//            // 
//            // roundedPanel6
//            // 
//            this.roundedPanel6.BackColor = System.Drawing.Color.White;
//            this.roundedPanel6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.roundedPanel6.BorderRadius = 6;
//            this.roundedPanel6.BorderSize = 1;
//            this.roundedPanel6.Controls.Add(this.textBox3);
//            this.roundedPanel6.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel6.Location = new System.Drawing.Point(97, 661);
//            this.roundedPanel6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel6.Name = "roundedPanel6";
//            this.roundedPanel6.Size = new System.Drawing.Size(229, 53);
//            this.roundedPanel6.TabIndex = 3;
//            this.roundedPanel6.Visible = false;
//            // 
//            // textBox3
//            // 
//            this.textBox3.BackColor = System.Drawing.Color.White;
//            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.textBox3.Location = new System.Drawing.Point(14, 15);
//            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.textBox3.Name = "textBox3";
//            this.textBox3.Size = new System.Drawing.Size(211, 23);
//            this.textBox3.TabIndex = 1;
//            // 
//            // label1
//            // 
//            this.label1.AutoSize = true;
//            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
//            this.label1.Location = new System.Drawing.Point(17, 20);
//            this.label1.Name = "label1";
//            this.label1.Size = new System.Drawing.Size(103, 25);
//            this.label1.TabIndex = 0;
//            this.label1.Text = "Thông tin";
//            // 
//            // roundedPanel9
//            // 
//            this.roundedPanel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Left) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.roundedPanel9.BackColor = System.Drawing.Color.White;
//            this.roundedPanel9.BorderColor = System.Drawing.SystemColors.ButtonFace;
//            this.roundedPanel9.BorderRadius = 20;
//            this.roundedPanel9.BorderSize = 2;
//            this.roundedPanel9.Controls.Add(this.buttoncd2);
//            this.roundedPanel9.Controls.Add(this.label22);
//            this.roundedPanel9.Controls.Add(this.label20);
//            this.roundedPanel9.Controls.Add(this.label18);
//            this.roundedPanel9.Controls.Add(this.label10);
//            this.roundedPanel9.Controls.Add(this.label7);
//            this.roundedPanel9.Controls.Add(this.label21);
//            this.roundedPanel9.Controls.Add(this.label19);
//            this.roundedPanel9.Controls.Add(this.label17);
//            this.roundedPanel9.Controls.Add(this.label8);
//            this.roundedPanel9.Controls.Add(this.label6);
//            this.roundedPanel9.Controls.Add(this.dataGridView1);
//            this.roundedPanel9.Controls.Add(this.label5);
//            this.roundedPanel9.ForeColor = System.Drawing.Color.Black;
//            this.roundedPanel9.Location = new System.Drawing.Point(1314, 108);
//            this.roundedPanel9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.roundedPanel9.Name = "roundedPanel9";
//            this.roundedPanel9.Size = new System.Drawing.Size(528, 892);
//            this.roundedPanel9.TabIndex = 9;
//            // 
//            // buttoncd2
//            // 
//            this.buttoncd2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            this.buttoncd2.BorderColor = System.Drawing.Color.AliceBlue;
//            this.buttoncd2.BorderRadius = 20;
//            this.buttoncd2.BorderSize = 0;
//            this.buttoncd2.FlatAppearance.BorderSize = 0;
//            this.buttoncd2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
//            this.buttoncd2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.buttoncd2.ForeColor = System.Drawing.Color.White;
//            this.buttoncd2.Location = new System.Drawing.Point(171, 785);
//            this.buttoncd2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.buttoncd2.Name = "buttoncd2";
//            this.buttoncd2.Size = new System.Drawing.Size(206, 67);
//            this.buttoncd2.TabIndex = 5;
//            this.buttoncd2.Text = "Hoàn thành";
//            this.buttoncd2.UseVisualStyleBackColor = false;
//            // 
//            // label22
//            // 
//            this.label22.AutoSize = true;
//            this.label22.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label22.Location = new System.Drawing.Point(352, 625);
//            this.label22.Name = "label22";
//            this.label22.Size = new System.Drawing.Size(59, 23);
//            this.label22.TabIndex = 4;
//            this.label22.Text = "maNH";
//            // 
//            // label20
//            // 
//            this.label20.AutoSize = true;
//            this.label20.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label20.Location = new System.Drawing.Point(352, 573);
//            this.label20.Name = "label20";
//            this.label20.Size = new System.Drawing.Size(59, 23);
//            this.label20.TabIndex = 4;
//            this.label20.Text = "maNH";
//            // 
//            // label18
//            // 
//            this.label18.AutoSize = true;
//            this.label18.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label18.Location = new System.Drawing.Point(352, 521);
//            this.label18.Name = "label18";
//            this.label18.Size = new System.Drawing.Size(59, 23);
//            this.label18.TabIndex = 4;
//            this.label18.Text = "maNH";
//            // 
//            // label10
//            // 
//            this.label10.AutoSize = true;
//            this.label10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label10.Location = new System.Drawing.Point(352, 476);
//            this.label10.Name = "label10";
//            this.label10.Size = new System.Drawing.Size(59, 23);
//            this.label10.TabIndex = 4;
//            this.label10.Text = "maNH";
//            // 
//            // label7
//            // 
//            this.label7.AutoSize = true;
//            this.label7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label7.Location = new System.Drawing.Point(352, 432);
//            this.label7.Name = "label7";
//            this.label7.Size = new System.Drawing.Size(126, 23);
//            this.label7.TabIndex = 4;
//            this.label7.Text = "Tên đối tác   00";
//            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
//            // 
//            // label21
//            // 
//            this.label21.AutoSize = true;
//            this.label21.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label21.Location = new System.Drawing.Point(111, 625);
//            this.label21.Name = "label21";
//            this.label21.Size = new System.Drawing.Size(108, 23);
//            this.label21.TabIndex = 4;
//            this.label21.Text = "Cần phải trả";
//            // 
//            // label19
//            // 
//            this.label19.AutoSize = true;
//            this.label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label19.Location = new System.Drawing.Point(111, 573);
//            this.label19.Name = "label19";
//            this.label19.Size = new System.Drawing.Size(82, 23);
//            this.label19.TabIndex = 4;
//            this.label19.Text = "Giảm giá";
//            // 
//            // label17
//            // 
//            this.label17.AutoSize = true;
//            this.label17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label17.Location = new System.Drawing.Point(111, 521);
//            this.label17.Name = "label17";
//            this.label17.Size = new System.Drawing.Size(87, 23);
//            this.label17.TabIndex = 4;
//            this.label17.Text = "Tổng tiền";
//            // 
//            // label8
//            // 
//            this.label8.AutoSize = true;
//            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label8.Location = new System.Drawing.Point(111, 476);
//            this.label8.Name = "label8";
//            this.label8.Size = new System.Drawing.Size(125, 23);
//            this.label8.TabIndex = 4;
//            this.label8.Text = "Mã nhập hàng";
//            // 
//            // label6
//            // 
//            this.label6.AutoSize = true;
//            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
//            this.label6.Location = new System.Drawing.Point(111, 432);
//            this.label6.Name = "label6";
//            this.label6.Size = new System.Drawing.Size(67, 23);
//            this.label6.TabIndex = 4;
//            this.label6.Text = "Đối tác";
//            // 
//            // dataGridView1
//            // 
//            this.dataGridView1.AllowUserToAddRows = false;
//            this.dataGridView1.AllowUserToDeleteRows = false;
//            this.dataGridView1.AllowUserToOrderColumns = true;
//            this.dataGridView1.AllowUserToResizeRows = false;
//            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
//            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
//            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
//            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
//            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
//            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
//            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
//            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
//            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
//            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
//            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
//            this.dataGridView1.ColumnHeadersHeight = 50;
//            this.dataGridView1.GridColor = System.Drawing.Color.White;
//            this.dataGridView1.Location = new System.Drawing.Point(17, 65);
//            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.dataGridView1.Name = "dataGridView1";
//            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
//            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
//            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
//            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
//            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
//            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
//            this.dataGridView1.RowHeadersVisible = false;
//            this.dataGridView1.RowHeadersWidth = 50;
//            this.dataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
//            this.dataGridView1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
//            this.dataGridView1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
//            this.dataGridView1.RowTemplate.Height = 40;
//            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
//            this.dataGridView1.Size = new System.Drawing.Size(499, 344);
//            this.dataGridView1.TabIndex = 7;
//            // 
//            // label5
//            // 
//            this.label5.AutoSize = true;
//            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
//            this.label5.Location = new System.Drawing.Point(17, 20);
//            this.label5.Name = "label5";
//            this.label5.Size = new System.Drawing.Size(115, 25);
//            this.label5.TabIndex = 0;
//            this.label5.Text = "Danh sách";
//            // 
//            // panel9
//            // 
//            this.panel9.Controls.Add(this.txtDisplayName);
//            this.panel9.Controls.Add(this.pictureBox7);
//            this.panel9.Controls.Add(this.displayName);
//            this.panel9.Location = new System.Drawing.Point(1399, 21);
//            this.panel9.Name = "panel9";
//            this.panel9.Size = new System.Drawing.Size(214, 37);
//            this.panel9.TabIndex = 5;
//            // 
//            // txtDisplayName
//            // 
//            this.txtDisplayName.BorderStyle = System.Windows.Forms.BorderStyle.None;
//            this.txtDisplayName.Location = new System.Drawing.Point(3, 10);
//            this.txtDisplayName.Name = "txtDisplayName";
//            this.txtDisplayName.Size = new System.Drawing.Size(172, 20);
//            this.txtDisplayName.TabIndex = 5;
//            this.txtDisplayName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // pictureBox7
//            // 
//            this.pictureBox7.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_profileUser;
//            this.pictureBox7.Location = new System.Drawing.Point(181, 4);
//            this.pictureBox7.Name = "pictureBox7";
//            this.pictureBox7.Size = new System.Drawing.Size(30, 28);
//            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
//            this.pictureBox7.TabIndex = 4;
//            this.pictureBox7.TabStop = false;
//            // 
//            // displayName
//            // 
//            this.displayName.AutoSize = true;
//            this.displayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.displayName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
//            this.displayName.Location = new System.Drawing.Point(15, 12);
//            this.displayName.Name = "displayName";
//            this.displayName.Size = new System.Drawing.Size(0, 18);
//            this.displayName.TabIndex = 3;
//            this.displayName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // fTransaction
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
//            this.ClientSize = new System.Drawing.Size(1856, 1015);
//            this.Controls.Add(this.roundedPanel9);
//            this.Controls.Add(this.roundedPanel1);
//            this.Controls.Add(this.roundedPanel3);
//            this.Controls.Add(this.panel2);
//            this.Controls.Add(this.panelMenu);
//            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
//            this.Name = "fTransaction";
//            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
//            this.Text = "fTransaction";
//            this.Load += new System.EventHandler(this.fTransaction_Load);
//            this.panel2.ResumeLayout(false);
//            this.panel3.ResumeLayout(false);
//            this.panel3.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
//            this.panel4.ResumeLayout(false);
//            this.panel4.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
//            this.tableListProduct.ResumeLayout(false);
//            this.tableListProduct.PerformLayout();
//            this.navForAdmin.ResumeLayout(false);
//            this.panelMenu.ResumeLayout(false);
//            this.roundedPanel1.ResumeLayout(false);
//            this.roundedPanel1.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.dtgvListProduct)).EndInit();
//            this.roundedPanel3.ResumeLayout(false);
//            this.roundedPanel3.PerformLayout();
//            this.roundedPanel5.ResumeLayout(false);
//            this.roundedPanel5.PerformLayout();
//            this.roundedPanel7.ResumeLayout(false);
//            this.roundedPanel7.PerformLayout();
//            this.roundedPanel10.ResumeLayout(false);
//            this.roundedPanel10.PerformLayout();
//            this.roundedPanel8.ResumeLayout(false);
//            this.roundedPanel8.PerformLayout();
//            this.roundedPanel2.ResumeLayout(false);
//            this.roundedPanel2.PerformLayout();
//            this.roundedPanel4.ResumeLayout(false);
//            this.roundedPanel4.PerformLayout();
//            this.roundedPanel6.ResumeLayout(false);
//            this.roundedPanel6.PerformLayout();
//            this.roundedPanel9.ResumeLayout(false);
//            this.roundedPanel9.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
//            this.panel9.ResumeLayout(false);
//            this.panel9.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
//            this.ResumeLayout(false);

//        }

//        #endregion
//        private Panel panel2;
//        private Panel panel3;
//        private Label showTimeDB;
//        private PictureBox pictureBox2;
//        private Panel panel4;
//        private PictureBox pictureBox1;
//        private TextBox textBox1;
//        private Panel panel1;
//        private TableLayoutPanel tableListProduct;
//        private Label label3;
//        private Label label4;
//        private Label label9;
//        private Button nav_sell;
//        private Button nav_product;
//        private Panel navForAdmin;
//        private Button nav_purchase;
//        private Button nav_bill;
//        private Button nav_report;
//        private Panel panelMenu;
//        private CustomDesign.RoundedPanel roundedPanel1;
//        public DataGridView dtgvListProduct;
//        private CustomDesign.RoundedPanel roundedPanel3;
//        private CustomDesign.RoundedPanel roundedPanel4;
//        private Label label2;
//        private Label label1;
//        private Label label13;
//        private CustomDesign.RoundedPanel roundedPanel5;
//        private Label label11;
//        private Label label15;
//        private CustomDesign.RoundedPanel roundedPanel2;
//        private TextBox textBox2;
//        private Label label12;
//        private CustomDesign.RoundedPanel roundedPanel6;
//        private TextBox textBox3;
//        private Label label14;
//        private CustomDesign.RoundedPanel roundedPanel7;
//        private TextBox textBox4;
//        private Label label16;
//        private CustomDesign.RoundedPanel roundedPanel8;
//        private TextBox textBox5;
//        private CustomDesign.ButtonCD buttoncd1;
//        private CustomDesign.RoundedPanel roundedPanel9;
//        private Label label5;
//        private Label label6;
//        public DataGridView dataGridView1;
//        private Label label7;
//        private Label label18;
//        private Label label10;
//        private Label label17;
//        private Label label8;
//        private Label label20;
//        private Label label19;
//        private Label label23;
//        private CustomDesign.RoundedPanel roundedPanel10;
//        private TextBox textBox6;
//        private CustomDesign.ButtonCD buttoncd2;
//        private Label label22;
//        private Label label21;
//        private Panel panel9;
//        private TextBox txtDisplayName;
//        private PictureBox pictureBox7;
//        private Label displayName;
//    }
//}