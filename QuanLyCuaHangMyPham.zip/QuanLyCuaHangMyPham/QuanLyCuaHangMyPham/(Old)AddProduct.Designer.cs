﻿//namespace QuanLyCuaHangMyPham
//{
//    partial class AddProduct
//    {
//        /// <summary>
//        /// Required designer variable.
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// Clean up any resources being used.
//        /// </summary>
//        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows Form Designer generated code

//        /// <summary>
//        /// Required method for Designer support - do not modify
//        /// the contents of this method with the code editor.
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.panelAddProduct = new System.Windows.Forms.Panel();
//            this.label11 = new System.Windows.Forms.Label();
//            this.panel6 = new System.Windows.Forms.Panel();
//            this.cbPartner = new System.Windows.Forms.ComboBox();
//            this.lblPartner = new System.Windows.Forms.Label();
//            this.panel3 = new System.Windows.Forms.Panel();
//            this.cbCategory = new System.Windows.Forms.ComboBox();
//            this.lblCategory = new System.Windows.Forms.Label();
//            this.button1 = new System.Windows.Forms.Button();
//            this.panel14 = new System.Windows.Forms.Panel();
//            this.label15 = new System.Windows.Forms.Label();
//            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
//            this.panel15 = new System.Windows.Forms.Panel();
//            this.label16 = new System.Windows.Forms.Label();
//            this.txtCategory = new System.Windows.Forms.TextBox();
//            this.panel13 = new System.Windows.Forms.Panel();
//            this.label14 = new System.Windows.Forms.Label();
//            this.txtAddress = new System.Windows.Forms.TextBox();
//            this.pnNewPartner = new System.Windows.Forms.Panel();
//            this.label13 = new System.Windows.Forms.Label();
//            this.txtNameOfPartner = new System.Windows.Forms.TextBox();
//            this.pnNewCategory = new System.Windows.Forms.Panel();
//            this.label3 = new System.Windows.Forms.Label();
//            this.txtNameOfCategory = new System.Windows.Forms.TextBox();
//            this.panel1 = new System.Windows.Forms.Panel();
//            this.label1 = new System.Windows.Forms.Label();
//            this.txbTenSP = new System.Windows.Forms.TextBox();
//            this.panel9 = new System.Windows.Forms.Panel();
//            this.label7 = new System.Windows.Forms.Label();
//            this.txtProductDescription = new System.Windows.Forms.TextBox();
//            this.panel8 = new System.Windows.Forms.Panel();
//            this.label6 = new System.Windows.Forms.Label();
//            this.txtSource = new System.Windows.Forms.TextBox();
//            this.panel7 = new System.Windows.Forms.Panel();
//            this.lblUnit = new System.Windows.Forms.Label();
//            this.txtUnit = new System.Windows.Forms.TextBox();
//            this.panel4 = new System.Windows.Forms.Panel();
//            this.label4 = new System.Windows.Forms.Label();
//            this.panel2 = new System.Windows.Forms.Panel();
//            this.label2 = new System.Windows.Forms.Label();
//            this.panel5 = new System.Windows.Forms.Panel();
//            this.nmAmount = new System.Windows.Forms.NumericUpDown();
//            this.label5 = new System.Windows.Forms.Label();
//            this.nmGiaNhap = new System.Windows.Forms.NumericUpDown();
//            this.nmGiaBan = new System.Windows.Forms.NumericUpDown();
//            this.panelAddProduct.SuspendLayout();
//            this.panel6.SuspendLayout();
//            this.panel3.SuspendLayout();
//            this.panel14.SuspendLayout();
//            this.panel15.SuspendLayout();
//            this.panel13.SuspendLayout();
//            this.pnNewPartner.SuspendLayout();
//            this.pnNewCategory.SuspendLayout();
//            this.panel1.SuspendLayout();
//            this.panel9.SuspendLayout();
//            this.panel8.SuspendLayout();
//            this.panel7.SuspendLayout();
//            this.panel4.SuspendLayout();
//            this.panel2.SuspendLayout();
//            this.panel5.SuspendLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.nmAmount)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nmGiaBan)).BeginInit();
//            this.SuspendLayout();
//            // 
//            // panelAddProduct
//            // 
//            this.panelAddProduct.BackColor = System.Drawing.Color.White;
//            this.panelAddProduct.Controls.Add(this.label11);
//            this.panelAddProduct.Controls.Add(this.panel6);
//            this.panelAddProduct.Controls.Add(this.panel3);
//            this.panelAddProduct.Controls.Add(this.button1);
//            this.panelAddProduct.Controls.Add(this.panel14);
//            this.panelAddProduct.Controls.Add(this.panel15);
//            this.panelAddProduct.Controls.Add(this.panel13);
//            this.panelAddProduct.Controls.Add(this.pnNewPartner);
//            this.panelAddProduct.Controls.Add(this.pnNewCategory);
//            this.panelAddProduct.Controls.Add(this.panel1);
//            this.panelAddProduct.Controls.Add(this.panel9);
//            this.panelAddProduct.Controls.Add(this.panel8);
//            this.panelAddProduct.Controls.Add(this.panel7);
//            this.panelAddProduct.Controls.Add(this.panel4);
//            this.panelAddProduct.Controls.Add(this.panel2);
//            this.panelAddProduct.Controls.Add(this.panel5);
//            this.panelAddProduct.Location = new System.Drawing.Point(12, 12);
//            this.panelAddProduct.Name = "panelAddProduct";
//            this.panelAddProduct.Size = new System.Drawing.Size(774, 675);
//            this.panelAddProduct.TabIndex = 6;
//            // 
//            // label11
//            // 
//            this.label11.AutoSize = true;
//            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
//            this.label11.Location = new System.Drawing.Point(36, 9);
//            this.label11.Name = "label11";
//            this.label11.Size = new System.Drawing.Size(120, 18);
//            this.label11.TabIndex = 6;
//            this.label11.Text = "Thêm thủ công";
//            // 
//            // panel6
//            // 
//            this.panel6.Controls.Add(this.cbPartner);
//            this.panel6.Controls.Add(this.lblPartner);
//            this.panel6.Location = new System.Drawing.Point(393, 42);
//            this.panel6.Name = "panel6";
//            this.panel6.Size = new System.Drawing.Size(342, 59);
//            this.panel6.TabIndex = 1;
//            // 
//            // cbPartner
//            // 
//            this.cbPartner.FormattingEnabled = true;
//            this.cbPartner.Items.AddRange(new object[] {
//            "Thêm mới..."});
//            this.cbPartner.Location = new System.Drawing.Point(139, 22);
//            this.cbPartner.Name = "cbPartner";
//            this.cbPartner.Size = new System.Drawing.Size(151, 26);
//            this.cbPartner.TabIndex = 2;
//            this.cbPartner.SelectedIndexChanged += new System.EventHandler(this.cbPartner_SelectedIndexChanged);
//            // 
//            // lblPartner
//            // 
//            this.lblPartner.AutoSize = true;
//            this.lblPartner.Location = new System.Drawing.Point(15, 25);
//            this.lblPartner.Name = "lblPartner";
//            this.lblPartner.Size = new System.Drawing.Size(99, 18);
//            this.lblPartner.TabIndex = 1;
//            this.lblPartner.Text = "Nhà cung cấp";
//            // 
//            // panel3
//            // 
//            this.panel3.Controls.Add(this.cbCategory);
//            this.panel3.Controls.Add(this.lblCategory);
//            this.panel3.Location = new System.Drawing.Point(33, 42);
//            this.panel3.Name = "panel3";
//            this.panel3.Size = new System.Drawing.Size(342, 59);
//            this.panel3.TabIndex = 1;
//            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
//            // 
//            // cbCategory
//            // 
//            this.cbCategory.FormattingEnabled = true;
//            this.cbCategory.Items.AddRange(new object[] {
//            "Thêm mới..."});
//            this.cbCategory.Location = new System.Drawing.Point(139, 22);
//            this.cbCategory.Name = "cbCategory";
//            this.cbCategory.Size = new System.Drawing.Size(151, 26);
//            this.cbCategory.TabIndex = 2;
//            this.cbCategory.SelectedIndexChanged += new System.EventHandler(this.cbCategory_SelectedIndexChanged);
//            // 
//            // lblCategory
//            // 
//            this.lblCategory.AutoSize = true;
//            this.lblCategory.Location = new System.Drawing.Point(15, 25);
//            this.lblCategory.Name = "lblCategory";
//            this.lblCategory.Size = new System.Drawing.Size(69, 18);
//            this.lblCategory.TabIndex = 1;
//            this.lblCategory.Text = "Phân loại";
//            // 
//            // button1
//            // 
//            this.button1.BackColor = System.Drawing.Color.DimGray;
//            this.button1.Location = new System.Drawing.Point(337, 577);
//            this.button1.Name = "button1";
//            this.button1.Size = new System.Drawing.Size(86, 36);
//            this.button1.TabIndex = 5;
//            this.button1.Text = "Thêm";
//            this.button1.UseVisualStyleBackColor = false;
//            this.button1.Click += new System.EventHandler(this.button1_Click);
//            // 
//            // panel14
//            // 
//            this.panel14.Controls.Add(this.label15);
//            this.panel14.Controls.Add(this.txtPhoneNumber);
//            this.panel14.Location = new System.Drawing.Point(393, 237);
//            this.panel14.Name = "panel14";
//            this.panel14.Size = new System.Drawing.Size(342, 59);
//            this.panel14.TabIndex = 1;
//            // 
//            // label15
//            // 
//            this.label15.AutoSize = true;
//            this.label15.Location = new System.Drawing.Point(15, 20);
//            this.label15.Name = "label15";
//            this.label15.Size = new System.Drawing.Size(94, 18);
//            this.label15.TabIndex = 1;
//            this.label15.Text = "Số điện thoại";
//            // 
//            // txtPhoneNumber
//            // 
//            this.txtPhoneNumber.Location = new System.Drawing.Point(139, 17);
//            this.txtPhoneNumber.Name = "txtPhoneNumber";
//            this.txtPhoneNumber.Size = new System.Drawing.Size(200, 24);
//            this.txtPhoneNumber.TabIndex = 1;
//            // 
//            // panel15
//            // 
//            this.panel15.Controls.Add(this.label16);
//            this.panel15.Controls.Add(this.txtCategory);
//            this.panel15.Location = new System.Drawing.Point(33, 172);
//            this.panel15.Name = "panel15";
//            this.panel15.Size = new System.Drawing.Size(342, 59);
//            this.panel15.TabIndex = 1;
//            // 
//            // label16
//            // 
//            this.label16.AutoSize = true;
//            this.label16.Location = new System.Drawing.Point(15, 20);
//            this.label16.Name = "label16";
//            this.label16.Size = new System.Drawing.Size(109, 18);
//            this.label16.TabIndex = 1;
//            this.label16.Text = "Mô tả phân loại";
//            // 
//            // txtCategory
//            // 
//            this.txtCategory.Location = new System.Drawing.Point(139, 17);
//            this.txtCategory.Name = "txtCategory";
//            this.txtCategory.Size = new System.Drawing.Size(200, 24);
//            this.txtCategory.TabIndex = 1;
//            // 
//            // panel13
//            // 
//            this.panel13.Controls.Add(this.label14);
//            this.panel13.Controls.Add(this.txtAddress);
//            this.panel13.Location = new System.Drawing.Point(393, 172);
//            this.panel13.Name = "panel13";
//            this.panel13.Size = new System.Drawing.Size(342, 59);
//            this.panel13.TabIndex = 1;
//            // 
//            // label14
//            // 
//            this.label14.AutoSize = true;
//            this.label14.Location = new System.Drawing.Point(15, 20);
//            this.label14.Name = "label14";
//            this.label14.Size = new System.Drawing.Size(53, 18);
//            this.label14.TabIndex = 1;
//            this.label14.Text = "Địa chỉ";
//            // 
//            // txtAddress
//            // 
//            this.txtAddress.Location = new System.Drawing.Point(139, 17);
//            this.txtAddress.Name = "txtAddress";
//            this.txtAddress.Size = new System.Drawing.Size(200, 24);
//            this.txtAddress.TabIndex = 1;
//            // 
//            // pnNewPartner
//            // 
//            this.pnNewPartner.Controls.Add(this.label13);
//            this.pnNewPartner.Controls.Add(this.txtNameOfPartner);
//            this.pnNewPartner.Location = new System.Drawing.Point(393, 107);
//            this.pnNewPartner.Name = "pnNewPartner";
//            this.pnNewPartner.Size = new System.Drawing.Size(342, 59);
//            this.pnNewPartner.TabIndex = 1;
//            // 
//            // label13
//            // 
//            this.label13.AutoSize = true;
//            this.label13.Location = new System.Drawing.Point(15, 20);
//            this.label13.Name = "label13";
//            this.label13.Size = new System.Drawing.Size(87, 18);
//            this.label13.TabIndex = 1;
//            this.label13.Text = "Tên nhà CC";
//            // 
//            // txtNameOfPartner
//            // 
//            this.txtNameOfPartner.Location = new System.Drawing.Point(139, 17);
//            this.txtNameOfPartner.Name = "txtNameOfPartner";
//            this.txtNameOfPartner.Size = new System.Drawing.Size(200, 24);
//            this.txtNameOfPartner.TabIndex = 1;
//            // 
//            // pnNewCategory
//            // 
//            this.pnNewCategory.Controls.Add(this.label3);
//            this.pnNewCategory.Controls.Add(this.txtNameOfCategory);
//            this.pnNewCategory.Location = new System.Drawing.Point(33, 107);
//            this.pnNewCategory.Name = "pnNewCategory";
//            this.pnNewCategory.Size = new System.Drawing.Size(342, 59);
//            this.pnNewCategory.TabIndex = 1;
//            // 
//            // label3
//            // 
//            this.label3.AutoSize = true;
//            this.label3.Location = new System.Drawing.Point(8, 20);
//            this.label3.Name = "label3";
//            this.label3.Size = new System.Drawing.Size(125, 18);
//            this.label3.TabIndex = 1;
//            this.label3.Text = "Tên phân loại mới";
//            // 
//            // txtNameOfCategory
//            // 
//            this.txtNameOfCategory.Location = new System.Drawing.Point(139, 17);
//            this.txtNameOfCategory.Name = "txtNameOfCategory";
//            this.txtNameOfCategory.Size = new System.Drawing.Size(200, 24);
//            this.txtNameOfCategory.TabIndex = 1;
//            // 
//            // panel1
//            // 
//            this.panel1.Controls.Add(this.label1);
//            this.panel1.Controls.Add(this.txbTenSP);
//            this.panel1.Location = new System.Drawing.Point(33, 303);
//            this.panel1.Name = "panel1";
//            this.panel1.Size = new System.Drawing.Size(342, 59);
//            this.panel1.TabIndex = 1;
//            // 
//            // label1
//            // 
//            this.label1.AutoSize = true;
//            this.label1.Location = new System.Drawing.Point(15, 25);
//            this.label1.Name = "label1";
//            this.label1.Size = new System.Drawing.Size(102, 18);
//            this.label1.TabIndex = 1;
//            this.label1.Text = "Tên sản phẩm";
//            // 
//            // txbTenSP
//            // 
//            this.txbTenSP.Location = new System.Drawing.Point(139, 17);
//            this.txbTenSP.Name = "txbTenSP";
//            this.txbTenSP.Size = new System.Drawing.Size(200, 24);
//            this.txbTenSP.TabIndex = 1;
//            // 
//            // panel9
//            // 
//            this.panel9.Controls.Add(this.label7);
//            this.panel9.Controls.Add(this.txtProductDescription);
//            this.panel9.Location = new System.Drawing.Point(393, 498);
//            this.panel9.Name = "panel9";
//            this.panel9.Size = new System.Drawing.Size(342, 59);
//            this.panel9.TabIndex = 1;
//            // 
//            // label7
//            // 
//            this.label7.AutoSize = true;
//            this.label7.Location = new System.Drawing.Point(15, 25);
//            this.label7.Name = "label7";
//            this.label7.Size = new System.Drawing.Size(115, 18);
//            this.label7.TabIndex = 1;
//            this.label7.Text = "Mô tả sản phẩm";
//            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            // 
//            // txtProductDescription
//            // 
//            this.txtProductDescription.Location = new System.Drawing.Point(139, 17);
//            this.txtProductDescription.Name = "txtProductDescription";
//            this.txtProductDescription.Size = new System.Drawing.Size(200, 24);
//            this.txtProductDescription.TabIndex = 3;
//            // 
//            // panel8
//            // 
//            this.panel8.Controls.Add(this.label6);
//            this.panel8.Controls.Add(this.txtSource);
//            this.panel8.Location = new System.Drawing.Point(33, 498);
//            this.panel8.Name = "panel8";
//            this.panel8.Size = new System.Drawing.Size(342, 59);
//            this.panel8.TabIndex = 1;
//            // 
//            // label6
//            // 
//            this.label6.AutoSize = true;
//            this.label6.Location = new System.Drawing.Point(15, 25);
//            this.label6.Name = "label6";
//            this.label6.Size = new System.Drawing.Size(57, 18);
//            this.label6.TabIndex = 1;
//            this.label6.Text = "Xuất xứ";
//            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
//            // 
//            // txtSource
//            // 
//            this.txtSource.Location = new System.Drawing.Point(139, 17);
//            this.txtSource.Name = "txtSource";
//            this.txtSource.Size = new System.Drawing.Size(200, 24);
//            this.txtSource.TabIndex = 3;
//            // 
//            // panel7
//            // 
//            this.panel7.Controls.Add(this.lblUnit);
//            this.panel7.Controls.Add(this.txtUnit);
//            this.panel7.Location = new System.Drawing.Point(393, 433);
//            this.panel7.Name = "panel7";
//            this.panel7.Size = new System.Drawing.Size(342, 59);
//            this.panel7.TabIndex = 1;
//            // 
//            // lblUnit
//            // 
//            this.lblUnit.AutoSize = true;
//            this.lblUnit.Location = new System.Drawing.Point(15, 25);
//            this.lblUnit.Name = "lblUnit";
//            this.lblUnit.Size = new System.Drawing.Size(77, 18);
//            this.lblUnit.TabIndex = 1;
//            this.lblUnit.Text = "Đơn vị tính";
//            // 
//            // txtUnit
//            // 
//            this.txtUnit.Location = new System.Drawing.Point(139, 17);
//            this.txtUnit.Name = "txtUnit";
//            this.txtUnit.Size = new System.Drawing.Size(200, 24);
//            this.txtUnit.TabIndex = 3;
//            // 
//            // panel4
//            // 
//            this.panel4.Controls.Add(this.nmGiaBan);
//            this.panel4.Controls.Add(this.label4);
//            this.panel4.Location = new System.Drawing.Point(393, 368);
//            this.panel4.Name = "panel4";
//            this.panel4.Size = new System.Drawing.Size(342, 59);
//            this.panel4.TabIndex = 1;
//            // 
//            // label4
//            // 
//            this.label4.AutoSize = true;
//            this.label4.Location = new System.Drawing.Point(15, 25);
//            this.label4.Name = "label4";
//            this.label4.Size = new System.Drawing.Size(59, 18);
//            this.label4.TabIndex = 1;
//            this.label4.Text = "Giá bán";
//            // 
//            // panel2
//            // 
//            this.panel2.Controls.Add(this.nmGiaNhap);
//            this.panel2.Controls.Add(this.label2);
//            this.panel2.Location = new System.Drawing.Point(33, 368);
//            this.panel2.Name = "panel2";
//            this.panel2.Size = new System.Drawing.Size(342, 59);
//            this.panel2.TabIndex = 1;
//            // 
//            // label2
//            // 
//            this.label2.AutoSize = true;
//            this.label2.Location = new System.Drawing.Point(15, 25);
//            this.label2.Name = "label2";
//            this.label2.Size = new System.Drawing.Size(67, 18);
//            this.label2.TabIndex = 1;
//            this.label2.Text = "Giá nhập";
//            // 
//            // panel5
//            // 
//            this.panel5.Controls.Add(this.nmAmount);
//            this.panel5.Controls.Add(this.label5);
//            this.panel5.Location = new System.Drawing.Point(33, 433);
//            this.panel5.Name = "panel5";
//            this.panel5.Size = new System.Drawing.Size(342, 59);
//            this.panel5.TabIndex = 1;
//            // 
//            // nmAmount
//            // 
//            this.nmAmount.Location = new System.Drawing.Point(189, 23);
//            this.nmAmount.Maximum = new decimal(new int[] {
//            100000000,
//            0,
//            0,
//            0});
//            this.nmAmount.Name = "nmAmount";
//            this.nmAmount.Size = new System.Drawing.Size(150, 24);
//            this.nmAmount.TabIndex = 2;
//            this.nmAmount.ThousandsSeparator = true;
//            // 
//            // label5
//            // 
//            this.label5.AutoSize = true;
//            this.label5.Location = new System.Drawing.Point(15, 25);
//            this.label5.Name = "label5";
//            this.label5.Size = new System.Drawing.Size(67, 18);
//            this.label5.TabIndex = 1;
//            this.label5.Text = "Số lượng";
//            // 
//            // nmGiaNhap
//            // 
//            this.nmGiaNhap.Increment = new decimal(new int[] {
//            500,
//            0,
//            0,
//            0});
//            this.nmGiaNhap.Location = new System.Drawing.Point(189, 23);
//            this.nmGiaNhap.Maximum = new decimal(new int[] {
//            1874919424,
//            2328306,
//            0,
//            0});
//            this.nmGiaNhap.Name = "nmGiaNhap";
//            this.nmGiaNhap.Size = new System.Drawing.Size(150, 24);
//            this.nmGiaNhap.TabIndex = 2;
//            this.nmGiaNhap.ThousandsSeparator = true;
//            // 
//            // nmGiaBan
//            // 
//            this.nmGiaBan.Increment = new decimal(new int[] {
//            500,
//            0,
//            0,
//            0});
//            this.nmGiaBan.Location = new System.Drawing.Point(178, 23);
//            this.nmGiaBan.Maximum = new decimal(new int[] {
//            1874919424,
//            2328306,
//            0,
//            0});
//            this.nmGiaBan.Name = "nmGiaBan";
//            this.nmGiaBan.Size = new System.Drawing.Size(150, 24);
//            this.nmGiaBan.TabIndex = 2;
//            this.nmGiaBan.ThousandsSeparator = true;
//            // 
//            // AddProduct
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
//            this.ClientSize = new System.Drawing.Size(803, 699);
//            this.Controls.Add(this.panelAddProduct);
//            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
//            this.Name = "AddProduct";
//            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
//            this.Text = "AddProduct";
//            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AddProduct_FormClosing);
//            this.Load += new System.EventHandler(this.AddProduct_Load);
//            this.panelAddProduct.ResumeLayout(false);
//            this.panelAddProduct.PerformLayout();
//            this.panel6.ResumeLayout(false);
//            this.panel6.PerformLayout();
//            this.panel3.ResumeLayout(false);
//            this.panel3.PerformLayout();
//            this.panel14.ResumeLayout(false);
//            this.panel14.PerformLayout();
//            this.panel15.ResumeLayout(false);
//            this.panel15.PerformLayout();
//            this.panel13.ResumeLayout(false);
//            this.panel13.PerformLayout();
//            this.pnNewPartner.ResumeLayout(false);
//            this.pnNewPartner.PerformLayout();
//            this.pnNewCategory.ResumeLayout(false);
//            this.pnNewCategory.PerformLayout();
//            this.panel1.ResumeLayout(false);
//            this.panel1.PerformLayout();
//            this.panel9.ResumeLayout(false);
//            this.panel9.PerformLayout();
//            this.panel8.ResumeLayout(false);
//            this.panel8.PerformLayout();
//            this.panel7.ResumeLayout(false);
//            this.panel7.PerformLayout();
//            this.panel4.ResumeLayout(false);
//            this.panel4.PerformLayout();
//            this.panel2.ResumeLayout(false);
//            this.panel2.PerformLayout();
//            this.panel5.ResumeLayout(false);
//            this.panel5.PerformLayout();
//            ((System.ComponentModel.ISupportInitialize)(this.nmAmount)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nmGiaNhap)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nmGiaBan)).EndInit();
//            this.ResumeLayout(false);

//        }

//        #endregion

//        private Panel panelAddProduct;
//        private Label label11;
//        private Panel panel6;
//        private ComboBox cbPartner;
//        private Label lblPartner;
//        private Panel panel3;
//        private ComboBox cbCategory;
//        private Label lblCategory;
//        private Button button1;
//        private Panel panel14;
//        private Label label15;
//        private TextBox txtPhoneNumber;
//        private Panel panel15;
//        private Label label16;
//        private TextBox txtCategory;
//        private Panel panel13;
//        private Label label14;
//        private TextBox txtAddress;
//        private Panel pnNewPartner;
//        private Label label13;
//        private TextBox txtNameOfPartner;
//        private Panel pnNewCategory;
//        private Label label3;
//        private TextBox txtNameOfCategory;
//        private Panel panel1;
//        private Label label1;
//        private TextBox txbTenSP;
//        private Panel panel7;
//        private Label lblUnit;
//        private TextBox txtUnit;
//        private Panel panel4;
//        private Label label4;
//        private Panel panel2;
//        private Label label2;
//        private Panel panel5;
//        private NumericUpDown nmAmount;
//        private Label label5;
//        private Panel panel8;
//        private Label label6;
//        private TextBox txtSource;
//        private Panel panel9;
//        private Label label7;
//        private TextBox txtProductDescription;
//        private NumericUpDown nmGiaBan;
//        public NumericUpDown nmGiaNhap;
//    }
//}