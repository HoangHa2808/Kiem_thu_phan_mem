﻿namespace QuanLyCuaHangMyPham
{
    partial class fReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fReport));
            this.panel1 = new System.Windows.Forms.Panel();
            this.navForAdmin = new System.Windows.Forms.Panel();
            this.nav_bill = new System.Windows.Forms.Button();
            this.nav_report = new System.Windows.Forms.Button();
            this.nav_purchase = new System.Windows.Forms.Button();
            this.nav_product = new System.Windows.Forms.Button();
            this.nav_sell = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtDisplayName = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.displayName = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.showTimeDB = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.lblAmountProduct = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.lblAmountInStock = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.lblBestSell = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.lblBadSell = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.roundedPanel2 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.dtgvBestSellProduct = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.roundedPanel1 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.roundedPanel3 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.roundedPanel4 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.roundedPanel5 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.roundedPanel6 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.roundedPanel7 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnShow = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpkToDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpkFromDate = new System.Windows.Forms.DateTimePicker();
            this.roundedPanel8 = new QuanLyCuaHangMyPham.CustomDesign.RoundedPanel();
            this.dtgvBadSellProduct = new System.Windows.Forms.DataGridView();
            this.label18 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.navForAdmin.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.roundedPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBestSellProduct)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.roundedPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBadSellProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.navForAdmin);
            this.panel1.Controls.Add(this.nav_product);
            this.panel1.Controls.Add(this.nav_sell);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 798);
            this.panel1.TabIndex = 2;
            // 
            // navForAdmin
            // 
            this.navForAdmin.Controls.Add(this.nav_bill);
            this.navForAdmin.Controls.Add(this.nav_report);
            this.navForAdmin.Controls.Add(this.nav_purchase);
            this.navForAdmin.Location = new System.Drawing.Point(0, 350);
            this.navForAdmin.Margin = new System.Windows.Forms.Padding(0);
            this.navForAdmin.Name = "navForAdmin";
            this.navForAdmin.Size = new System.Drawing.Size(200, 140);
            this.navForAdmin.TabIndex = 5;
            // 
            // nav_bill
            // 
            this.nav_bill.BackColor = System.Drawing.Color.White;
            this.nav_bill.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.nav_bill.FlatAppearance.BorderSize = 0;
            this.nav_bill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nav_bill.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
            this.nav_bill.Image = ((System.Drawing.Image)(resources.GetObject("nav_bill.Image")));
            this.nav_bill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_bill.Location = new System.Drawing.Point(20, 45);
            this.nav_bill.Name = "nav_bill";
            this.nav_bill.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.nav_bill.Size = new System.Drawing.Size(160, 40);
            this.nav_bill.TabIndex = 4;
            this.nav_bill.Text = "        Hóa đơn";
            this.nav_bill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_bill.UseVisualStyleBackColor = false;
            this.nav_bill.Click += new System.EventHandler(this.nav_bill_Click);
            // 
            // nav_report
            // 
            this.nav_report.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.nav_report.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.nav_report.FlatAppearance.BorderSize = 0;
            this.nav_report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nav_report.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
            this.nav_report.Image = ((System.Drawing.Image)(resources.GetObject("nav_report.Image")));
            this.nav_report.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_report.Location = new System.Drawing.Point(20, 90);
            this.nav_report.Margin = new System.Windows.Forms.Padding(0);
            this.nav_report.Name = "nav_report";
            this.nav_report.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.nav_report.Size = new System.Drawing.Size(160, 40);
            this.nav_report.TabIndex = 4;
            this.nav_report.Text = "        Báo cáo";
            this.nav_report.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_report.UseVisualStyleBackColor = false;
            // 
            // nav_purchase
            // 
            this.nav_purchase.BackColor = System.Drawing.Color.White;
            this.nav_purchase.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.nav_purchase.FlatAppearance.BorderSize = 0;
            this.nav_purchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nav_purchase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
            this.nav_purchase.Image = ((System.Drawing.Image)(resources.GetObject("nav_purchase.Image")));
            this.nav_purchase.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_purchase.Location = new System.Drawing.Point(20, 0);
            this.nav_purchase.Margin = new System.Windows.Forms.Padding(0);
            this.nav_purchase.Name = "nav_purchase";
            this.nav_purchase.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.nav_purchase.Size = new System.Drawing.Size(160, 40);
            this.nav_purchase.TabIndex = 4;
            this.nav_purchase.Text = "        Nhập hàng";
            this.nav_purchase.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_purchase.UseVisualStyleBackColor = false;
            this.nav_purchase.Click += new System.EventHandler(this.nav_purchase_Click);
            // 
            // nav_product
            // 
            this.nav_product.BackColor = System.Drawing.Color.White;
            this.nav_product.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.nav_product.FlatAppearance.BorderSize = 0;
            this.nav_product.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nav_product.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
            this.nav_product.Image = ((System.Drawing.Image)(resources.GetObject("nav_product.Image")));
            this.nav_product.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_product.Location = new System.Drawing.Point(20, 305);
            this.nav_product.Name = "nav_product";
            this.nav_product.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.nav_product.Size = new System.Drawing.Size(160, 40);
            this.nav_product.TabIndex = 4;
            this.nav_product.Text = "        Sản phẩm";
            this.nav_product.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_product.UseVisualStyleBackColor = false;
            this.nav_product.Click += new System.EventHandler(this.nav_product_Click);
            // 
            // nav_sell
            // 
            this.nav_sell.BackColor = System.Drawing.Color.White;
            this.nav_sell.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.nav_sell.FlatAppearance.BorderSize = 0;
            this.nav_sell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nav_sell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(123)))), ((int)(((byte)(146)))));
            this.nav_sell.Image = ((System.Drawing.Image)(resources.GetObject("nav_sell.Image")));
            this.nav_sell.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_sell.Location = new System.Drawing.Point(20, 260);
            this.nav_sell.Name = "nav_sell";
            this.nav_sell.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.nav_sell.Size = new System.Drawing.Size(160, 40);
            this.nav_sell.TabIndex = 4;
            this.nav_sell.Text = "        Bán hàng";
            this.nav_sell.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.nav_sell.UseVisualStyleBackColor = false;
            this.nav_sell.Click += new System.EventHandler(this.nav_sell_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1064, 63);
            this.panel2.TabIndex = 3;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txtDisplayName);
            this.panel9.Controls.Add(this.pictureBox7);
            this.panel9.Controls.Add(this.displayName);
            this.panel9.Location = new System.Drawing.Point(838, 12);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(214, 37);
            this.panel9.TabIndex = 5;
            // 
            // txtDisplayName
            // 
            this.txtDisplayName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDisplayName.Location = new System.Drawing.Point(3, 10);
            this.txtDisplayName.Name = "txtDisplayName";
            this.txtDisplayName.Size = new System.Drawing.Size(172, 17);
            this.txtDisplayName.TabIndex = 5;
            this.txtDisplayName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_profileUser;
            this.pictureBox7.Location = new System.Drawing.Point(181, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(30, 28);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            // 
            // displayName
            // 
            this.displayName.AutoSize = true;
            this.displayName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.displayName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.displayName.Location = new System.Drawing.Point(15, 12);
            this.displayName.Name = "displayName";
            this.displayName.Size = new System.Drawing.Size(0, 18);
            this.displayName.TabIndex = 3;
            this.displayName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.showTimeDB);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(143)))), ((int)(((byte)(172)))));
            this.panel3.Location = new System.Drawing.Point(1544, -19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(143, 37);
            this.panel3.TabIndex = 3;
            // 
            // showTimeDB
            // 
            this.showTimeDB.AutoSize = true;
            this.showTimeDB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.showTimeDB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.showTimeDB.Location = new System.Drawing.Point(54, 12);
            this.showTimeDB.MaximumSize = new System.Drawing.Size(69, 13);
            this.showTimeDB.MinimumSize = new System.Drawing.Size(69, 13);
            this.showTimeDB.Name = "showTimeDB";
            this.showTimeDB.Size = new System.Drawing.Size(69, 13);
            this.showTimeDB.TabIndex = 3;
            this.showTimeDB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_calendar;
            this.pictureBox2.Location = new System.Drawing.Point(20, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Controls.Add(this.textBox1);
            this.panel4.Location = new System.Drawing.Point(38, 15);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 38);
            this.panel4.TabIndex = 0;
            this.panel4.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_search;
            this.pictureBox1.Location = new System.Drawing.Point(10, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 15);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
            this.textBox1.Location = new System.Drawing.Point(32, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.PlaceholderText = "Search";
            this.textBox1.Size = new System.Drawing.Size(165, 24);
            this.textBox1.TabIndex = 5;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.label10);
            this.panel10.Controls.Add(this.lblAmountProduct);
            this.panel10.Controls.Add(this.pictureBox8);
            this.panel10.Location = new System.Drawing.Point(220, 69);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(240, 120);
            this.panel10.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(110, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 18);
            this.label10.TabIndex = 2;
            this.label10.Text = "Tổng số sản phẩm";
            // 
            // lblAmountProduct
            // 
            this.lblAmountProduct.AutoSize = true;
            this.lblAmountProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAmountProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.lblAmountProduct.Location = new System.Drawing.Point(110, 30);
            this.lblAmountProduct.Name = "lblAmountProduct";
            this.lblAmountProduct.Size = new System.Drawing.Size(87, 36);
            this.lblAmountProduct.TabIndex = 1;
            this.lblAmountProduct.Text = "2001";
            this.lblAmountProduct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAmountProduct.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_product;
            this.pictureBox8.Location = new System.Drawing.Point(30, 30);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(60, 60);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.label12);
            this.panel11.Controls.Add(this.lblAmountInStock);
            this.panel11.Controls.Add(this.pictureBox9);
            this.panel11.Location = new System.Drawing.Point(480, 69);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(240, 120);
            this.panel11.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(110, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 18);
            this.label12.TabIndex = 2;
            this.label12.Text = "Số lượng tồn";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAmountInStock
            // 
            this.lblAmountInStock.AutoSize = true;
            this.lblAmountInStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAmountInStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.lblAmountInStock.Location = new System.Drawing.Point(110, 30);
            this.lblAmountInStock.Name = "lblAmountInStock";
            this.lblAmountInStock.Size = new System.Drawing.Size(87, 36);
            this.lblAmountInStock.TabIndex = 1;
            this.lblAmountInStock.Text = "2001";
            this.lblAmountInStock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblAmountInStock.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_product;
            this.pictureBox9.Location = new System.Drawing.Point(30, 30);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(60, 60);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.label14);
            this.panel12.Controls.Add(this.lblBestSell);
            this.panel12.Controls.Add(this.pictureBox10);
            this.panel12.Location = new System.Drawing.Point(740, 69);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(240, 120);
            this.panel12.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(110, 76);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(130, 18);
            this.label14.TabIndex = 2;
            this.label14.Text = "Số lượng bán chạy";
            // 
            // lblBestSell
            // 
            this.lblBestSell.AutoSize = true;
            this.lblBestSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBestSell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.lblBestSell.Location = new System.Drawing.Point(110, 30);
            this.lblBestSell.Name = "lblBestSell";
            this.lblBestSell.Size = new System.Drawing.Size(87, 36);
            this.lblBestSell.TabIndex = 1;
            this.lblBestSell.Text = "2001";
            this.lblBestSell.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBestSell.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_product;
            this.pictureBox10.Location = new System.Drawing.Point(30, 30);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(60, 60);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.label17);
            this.panel13.Controls.Add(this.lblBadSell);
            this.panel13.Controls.Add(this.pictureBox11);
            this.panel13.Location = new System.Drawing.Point(1000, 69);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(240, 120);
            this.panel13.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(110, 76);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(136, 18);
            this.label17.TabIndex = 2;
            this.label17.Text = "Số lượng bán chậm";
            // 
            // lblBadSell
            // 
            this.lblBadSell.AutoSize = true;
            this.lblBadSell.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblBadSell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(67)))), ((int)(((byte)(100)))));
            this.lblBadSell.Location = new System.Drawing.Point(110, 30);
            this.lblBadSell.Name = "lblBadSell";
            this.lblBadSell.Size = new System.Drawing.Size(87, 36);
            this.lblBadSell.TabIndex = 1;
            this.lblBadSell.Text = "2001";
            this.lblBadSell.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBadSell.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::QuanLyCuaHangMyPham.Properties.Resources.icon_product;
            this.pictureBox11.Location = new System.Drawing.Point(30, 30);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(60, 60);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            // 
            // roundedPanel2
            // 
            this.roundedPanel2.BackColor = System.Drawing.Color.White;
            this.roundedPanel2.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel2.BorderRadius = 20;
            this.roundedPanel2.BorderSize = 0;
            this.roundedPanel2.Controls.Add(this.dtgvBestSellProduct);
            this.roundedPanel2.Controls.Add(this.label1);
            this.roundedPanel2.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel2.Location = new System.Drawing.Point(220, 335);
            this.roundedPanel2.Name = "roundedPanel2";
            this.roundedPanel2.Size = new System.Drawing.Size(1020, 213);
            this.roundedPanel2.TabIndex = 6;
            // 
            // dtgvBestSellProduct
            // 
            this.dtgvBestSellProduct.AllowUserToAddRows = false;
            this.dtgvBestSellProduct.AllowUserToResizeRows = false;
            this.dtgvBestSellProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvBestSellProduct.BackgroundColor = System.Drawing.Color.White;
            this.dtgvBestSellProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvBestSellProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dtgvBestSellProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dtgvBestSellProduct.ColumnHeadersHeight = 50;
            this.dtgvBestSellProduct.Location = new System.Drawing.Point(18, 33);
            this.dtgvBestSellProduct.Name = "dtgvBestSellProduct";
            this.dtgvBestSellProduct.ReadOnly = true;
            this.dtgvBestSellProduct.RowHeadersVisible = false;
            this.dtgvBestSellProduct.RowHeadersWidth = 51;
            this.dtgvBestSellProduct.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
            this.dtgvBestSellProduct.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
            this.dtgvBestSellProduct.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
            this.dtgvBestSellProduct.RowTemplate.Height = 29;
            this.dtgvBestSellProduct.Size = new System.Drawing.Size(983, 173);
            this.dtgvBestSellProduct.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(73)))), ((int)(((byte)(105)))));
            this.label1.Location = new System.Drawing.Point(18, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Top sản phẩm bán chạy";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // roundedPanel1
            // 
            this.roundedPanel1.BackColor = System.Drawing.Color.White;
            this.roundedPanel1.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel1.BorderRadius = 20;
            this.roundedPanel1.BorderSize = 0;
            this.roundedPanel1.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel1.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel1.Name = "roundedPanel1";
            this.roundedPanel1.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label4.Location = new System.Drawing.Point(3, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(5, 60);
            this.label4.TabIndex = 0;
            this.label4.Text = "STT";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label5.Location = new System.Drawing.Point(14, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 60);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tên sản phẩm";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roundedPanel3
            // 
            this.roundedPanel3.BackColor = System.Drawing.Color.White;
            this.roundedPanel3.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel3.BorderRadius = 20;
            this.roundedPanel3.BorderSize = 0;
            this.roundedPanel3.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel3.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel3.Name = "roundedPanel3";
            this.roundedPanel3.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label6.Location = new System.Drawing.Point(3, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(5, 60);
            this.label6.TabIndex = 0;
            this.label6.Text = "STT";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label7.Location = new System.Drawing.Point(14, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 60);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên sản phẩm";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roundedPanel4
            // 
            this.roundedPanel4.BackColor = System.Drawing.Color.White;
            this.roundedPanel4.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel4.BorderRadius = 20;
            this.roundedPanel4.BorderSize = 0;
            this.roundedPanel4.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel4.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel4.Name = "roundedPanel4";
            this.roundedPanel4.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel3.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label8.Location = new System.Drawing.Point(3, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(5, 60);
            this.label8.TabIndex = 0;
            this.label8.Text = "STT";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label9.Location = new System.Drawing.Point(14, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 60);
            this.label9.TabIndex = 0;
            this.label9.Text = "Tên sản phẩm";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roundedPanel5
            // 
            this.roundedPanel5.BackColor = System.Drawing.Color.White;
            this.roundedPanel5.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel5.BorderRadius = 20;
            this.roundedPanel5.BorderSize = 0;
            this.roundedPanel5.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel5.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel5.Name = "roundedPanel5";
            this.roundedPanel5.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel5.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label11.Location = new System.Drawing.Point(3, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(5, 60);
            this.label11.TabIndex = 0;
            this.label11.Text = "STT";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label13.Location = new System.Drawing.Point(14, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 60);
            this.label13.TabIndex = 0;
            this.label13.Text = "Tên sản phẩm";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roundedPanel6
            // 
            this.roundedPanel6.BackColor = System.Drawing.Color.White;
            this.roundedPanel6.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel6.BorderRadius = 20;
            this.roundedPanel6.BorderSize = 0;
            this.roundedPanel6.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel6.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel6.Name = "roundedPanel6";
            this.roundedPanel6.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel6.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel5.ColumnCount = 5;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel5.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label15.Location = new System.Drawing.Point(3, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(5, 60);
            this.label15.TabIndex = 0;
            this.label15.Text = "STT";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label16.Location = new System.Drawing.Point(14, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 60);
            this.label16.TabIndex = 0;
            this.label16.Text = "Tên sản phẩm";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roundedPanel7
            // 
            this.roundedPanel7.BackColor = System.Drawing.Color.White;
            this.roundedPanel7.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel7.BorderRadius = 20;
            this.roundedPanel7.BorderSize = 0;
            this.roundedPanel7.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel7.Location = new System.Drawing.Point(0, 0);
            this.roundedPanel7.Name = "roundedPanel7";
            this.roundedPanel7.Size = new System.Drawing.Size(150, 40);
            this.roundedPanel7.TabIndex = 0;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel6.ColumnCount = 5;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.714286F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.01017F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.14242F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.48423F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.46287F));
            this.tableLayoutPanel6.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label22.Location = new System.Drawing.Point(3, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(5, 60);
            this.label22.TabIndex = 0;
            this.label22.Text = "STT";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(134)))), ((int)(((byte)(164)))));
            this.label23.Location = new System.Drawing.Point(14, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 60);
            this.label23.TabIndex = 0;
            this.label23.Text = "Tên sản phẩm";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnShow
            // 
            this.btnShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnShow.Location = new System.Drawing.Point(1103, 287);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(94, 29);
            this.btnShow.TabIndex = 15;
            this.btnShow.Text = "Thống kê";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(1088, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "Đến ngày";
            // 
            // dtpkToDate
            // 
            this.dtpkToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkToDate.Location = new System.Drawing.Point(1088, 251);
            this.dtpkToDate.Name = "dtpkToDate";
            this.dtpkToDate.Size = new System.Drawing.Size(109, 24);
            this.dtpkToDate.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(969, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 18);
            this.label3.TabIndex = 14;
            this.label3.Text = "Từ ngày";
            // 
            // dtpkFromDate
            // 
            this.dtpkFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkFromDate.Location = new System.Drawing.Point(969, 251);
            this.dtpkFromDate.Name = "dtpkFromDate";
            this.dtpkFromDate.Size = new System.Drawing.Size(100, 24);
            this.dtpkFromDate.TabIndex = 12;
            // 
            // roundedPanel8
            // 
            this.roundedPanel8.BackColor = System.Drawing.Color.White;
            this.roundedPanel8.BorderColor = System.Drawing.Color.AliceBlue;
            this.roundedPanel8.BorderRadius = 20;
            this.roundedPanel8.BorderSize = 0;
            this.roundedPanel8.Controls.Add(this.dtgvBadSellProduct);
            this.roundedPanel8.Controls.Add(this.label18);
            this.roundedPanel8.ForeColor = System.Drawing.Color.Black;
            this.roundedPanel8.Location = new System.Drawing.Point(220, 571);
            this.roundedPanel8.Name = "roundedPanel8";
            this.roundedPanel8.Size = new System.Drawing.Size(1020, 213);
            this.roundedPanel8.TabIndex = 6;
            // 
            // dtgvBadSellProduct
            // 
            this.dtgvBadSellProduct.AllowUserToAddRows = false;
            this.dtgvBadSellProduct.AllowUserToResizeRows = false;
            this.dtgvBadSellProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvBadSellProduct.BackgroundColor = System.Drawing.Color.White;
            this.dtgvBadSellProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgvBadSellProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dtgvBadSellProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dtgvBadSellProduct.ColumnHeadersHeight = 50;
            this.dtgvBadSellProduct.Location = new System.Drawing.Point(18, 33);
            this.dtgvBadSellProduct.Name = "dtgvBadSellProduct";
            this.dtgvBadSellProduct.ReadOnly = true;
            this.dtgvBadSellProduct.RowHeadersVisible = false;
            this.dtgvBadSellProduct.RowHeadersWidth = 51;
            this.dtgvBadSellProduct.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(89)))), ((int)(((byte)(117)))));
            this.dtgvBadSellProduct.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(246)))), ((int)(((byte)(251)))));
            this.dtgvBadSellProduct.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(145)))), ((int)(((byte)(255)))));
            this.dtgvBadSellProduct.RowTemplate.Height = 29;
            this.dtgvBadSellProduct.Size = new System.Drawing.Size(983, 173);
            this.dtgvBadSellProduct.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(73)))), ((int)(((byte)(105)))));
            this.label18.Location = new System.Drawing.Point(18, 5);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(250, 25);
            this.label18.TabIndex = 6;
            this.label18.Text = "Top sản phẩm bán chậm";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(1264, 798);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpkToDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpkFromDate);
            this.Controls.Add(this.roundedPanel8);
            this.Controls.Add(this.roundedPanel2);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "fReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fReport";
            this.Load += new System.EventHandler(this.fReport_Load);
            this.panel1.ResumeLayout(false);
            this.navForAdmin.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.roundedPanel2.ResumeLayout(false);
            this.roundedPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBestSellProduct)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.roundedPanel8.ResumeLayout(false);
            this.roundedPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBadSellProduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Panel navForAdmin;
        private Button nav_bill;
        private Button nav_report;
        private Button nav_purchase;
        private Button nav_product;
        private Button nav_sell;
        private Panel panel2;
        private Panel panel3;
        private Label showTimeDB;
        private PictureBox pictureBox2;
        private Panel panel4;
        private PictureBox pictureBox1;
        private TextBox textBox1;
        private Panel panel10;
        private Label label10;
        private Label lblAmountProduct;
        private PictureBox pictureBox8;
        private Panel panel11;
        private Label label12;
        private Label lblAmountInStock;
        private PictureBox pictureBox9;
        private Panel panel12;
        private Label label14;
        private Label lblBestSell;
        private PictureBox pictureBox10;
        private Panel panel13;
        private Label label17;
        private Label lblBadSell;
        private PictureBox pictureBox11;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private CustomDesign.RoundedPanel roundedPanel2;
        private Label label1;
        private CustomDesign.RoundedPanel roundedPanel1;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label4;
        private Label label5;
        private CustomDesign.RoundedPanel roundedPanel3;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label6;
        private Label label7;
        private CustomDesign.RoundedPanel roundedPanel4;
        private TableLayoutPanel tableLayoutPanel3;
        private Label label8;
        private Label label9;
        private CustomDesign.RoundedPanel roundedPanel5;
        private TableLayoutPanel tableLayoutPanel4;
        private Label label11;
        private Label label13;
        private CustomDesign.RoundedPanel roundedPanel6;
        private TableLayoutPanel tableLayoutPanel5;
        private Label label15;
        private Label label16;
        private CustomDesign.RoundedPanel roundedPanel7;
        private TableLayoutPanel tableLayoutPanel6;
        private Label label22;
        private Label label23;
        private Button btnShow;
        private Label label2;
        private DateTimePicker dtpkToDate;
        private Label label3;
        private DateTimePicker dtpkFromDate;
        private CustomDesign.RoundedPanel roundedPanel8;
        private Label label18;
        private Panel panel9;
        private TextBox txtDisplayName;
        private PictureBox pictureBox7;
        private Label displayName;
        private DataGridView dtgvBestSellProduct;
        private DataGridView dtgvBadSellProduct;
    }
}